package com.alex.common;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DotaUserServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
