package com.alex.util;

/**
 * wechat token 相关的业务
 */
public class WeChatTokenUtil {

    public static void sendOauthRequest(){

    }
}
