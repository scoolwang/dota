package com.alex.gateway;

//@SpringBootTest
class DotaGatewayApplicationTests {

//    @Test
    void contextLoads() {
    }

}
