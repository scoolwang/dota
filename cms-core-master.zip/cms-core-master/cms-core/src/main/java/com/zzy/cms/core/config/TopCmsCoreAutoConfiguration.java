package com.zzy.cms.core.config;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.context.support.ConversionServiceFactoryBean;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.convert.converter.Converter;

import com.zzy.cms.core.util.random.SnowflakeIdWorker;
import com.zzy.cms.core.util.spring.SpringBeanUtil;

/**
 * @author guokaige
 */
@Configuration
@Import({SpringBeanUtil.class,CmsApplicationRunner.class, SnowflakeIdWorker.class})
public class TopCmsCoreAutoConfiguration {
	
	@SuppressWarnings("rawtypes")
	@Autowired
	Set<Converter> conveterList;

    @Bean
    public DateConverter dateConverter() {
        return new DateConverter();
    }
    
    @Bean
    public TimestampConverter timestampConverter() {
        return new TimestampConverter();
    }
    
    @Bean(name="conversionService")
    public ConversionService getConversionService() {
        ConversionServiceFactoryBean bean = new ConversionServiceFactoryBean();
        bean.setConverters(conveterList);
        bean.afterPropertiesSet();
        return bean.getObject();
    }
    
    
}