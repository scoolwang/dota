package com.zzy.cms.core.util.string;

import java.io.UnsupportedEncodingException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.zzy.cms.core.constant.CharsetConst;

/**
 * 
 * @author guokaige
 *
 */
public final class StringsUtils {

	public static final String COMMA = ",";
	public static final String VERTICAL = "|";
	public static final String INTERNET_PREFIX_HTTP = "http://";
	public static final String INTERNET_PREFIX_HTTPS = "https://";

	public static final String FOLDER_SEPARATOR = "/";

	public static final String WINDOWS_FOLDER_SEPARATOR = "\\";

	public static final String TOP_PATH = "..";

	public static final String CURRENT_PATH = ".";

	public static final char EXTENSION_SEPARATOR = '.';

	public static final String UNDERLINE = "_";

	/**
	 * Check whether the given CharSequence has actual text.
	 */
	public static boolean hasText(CharSequence str) {
		if (!hasLength(str)) {
			return false;
		}
		int strLen = str.length();
		for (int i = 0; i < strLen; i++) {
			if (!Character.isWhitespace(str.charAt(i))) {
				return true;
			}
		}
		return false;
	}

//	java.lang.Character.isWhitespace(char ch) 确定指定的字符是否为Java空白。字符是一个Java空白字符，当且仅当它满足下列条件之一：
//
//	它是一个Unicode字符空格 (SPACE_SEPARATOR, LINE_SEPARATOR, or PARAGRAPH_SEPARATOR) 但不也是非间断空格('u00A0', 'u2007', 'u202F').
//
//	它是 '	', U+0009 HORIZONTAL TABULATION.
//
//	它是 ' ', U+000A LINE FEED.
//
//	它是 'u000B', U+000B VERTICAL TABULATION.
//
//	它是 'f', U+000C FORM FEED.
//
//	它是 ' ', U+000D CARRIAGE RETURN.
//
//	它是 'u001C', U+001C FILE SEPARATOR.
//
//	它是 'u001D', U+001D GROUP SEPARATOR.
//
//	它是 'u001E', U+001E RECORD SEPARATOR.
//
//	它是 'u001F', U+001F UNIT SEPARATOR.

	/**
	 * 字符(不包含空格字符串)不为空
	 * 
	 * @Title: title
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @param str
	 * @return
	 * @version V3.0
	 * @author guokaige@topnet.net.cn
	 * @Date 2016年11月7日 下午1:18:55
	 */
	public static boolean hasText(String str) {
		return hasText((CharSequence) str);
	}

	/**
	 * 不包含字符串
	 * 
	 * @param str
	 * @return
	 */
	public static boolean hasNotText(String str) {
		return !hasText((CharSequence) str);
	}

	/**
	 * 正则
	 */
	public static final Pattern PATTERN_NUMBER = Pattern.compile("[-]?[0-9]*");

	public static boolean isNumeric(String str) {

		Matcher isNum = PATTERN_NUMBER.matcher(str);
		if (!isNum.matches()) {
			return false;
		}
		return true;
	}

	/**
	 * 包含空白字段
	 * 
	 * @Title: title
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @param str
	 * @return
	 * @version V3.0
	 * @author guokaige@topnet.net.cn
	 * @Date 2016年11月7日 下午1:12:04
	 */
	public static boolean containsWhitespace(CharSequence str) {
		if (!hasLength(str)) {
			return false;
		}
		int strLen = str.length();
		for (int i = 0; i < strLen; i++) {
			if (Character.isWhitespace(str.charAt(i))) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 字符(包含空格字符串)长度大于0
	 * 
	 * @Title: title
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @param str
	 * @return
	 * @version V3.0
	 * @author guokaige@topnet.net.cn
	 * @Date 2016年11月7日 下午1:17:50
	 */
	public static boolean hasLength(CharSequence str) {
		return (str != null && str.length() > 0);
	}

	/**
	 * 包含空白字段
	 * 
	 * @Title: title
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @param str
	 * @return
	 * @version V3.0
	 * @author guokaige@topnet.net.cn
	 * @Date 2016年11月7日 下午1:12:04
	 */
	public static boolean containsWhitespace(String str) {
		return containsWhitespace((CharSequence) str);
	}

	/**
	 * 去除空白字段
	 * 
	 * @Title: title
	 * @Description: TODO(这里用一句话描述这个方法的作用)
	 * @param str
	 * @return
	 * @version V3.0
	 * @author guokaige@topnet.net.cn
	 * @Date 2016年11月7日 下午1:12:04
	 */
	public static String trimAllWhitespace(String str) {
		if (!hasLength(str)) {
			return str;
		}
		StringBuffer buf = new StringBuffer(str);
		int index = 0;
		while (buf.length() > index) {
			if (Character.isWhitespace(buf.charAt(index))) {
				buf.deleteCharAt(index);
			} else {
				index++;
			}
		}
		return buf.toString();
	}

	/**
	 * Trim leading whitespace from the given String.
	 */
	public static String trimLeadingWhitespace(String str) {
		if (!hasLength(str)) {
			return str;
		}
		StringBuffer buf = new StringBuffer(str);
		while (buf.length() > 0 && Character.isWhitespace(buf.charAt(0))) {
			buf.deleteCharAt(0);
		}
		return buf.toString();
	}

	/**
	 * Trim trailing whitespace from the given String.
	 */
	public static String trimTrailingWhitespace(String str) {
		if (!hasLength(str)) {
			return str;
		}
		StringBuffer buf = new StringBuffer(str);
		while (buf.length() > 0 && Character.isWhitespace(buf.charAt(buf.length() - 1))) {
			buf.deleteCharAt(buf.length() - 1);
		}
		return buf.toString();
	}

	/**
	 * Trim all occurences of the supplied leading character from the given String.
	 */
	public static String trimLeadingCharacter(String str, char leadingCharacter) {
		if (!hasLength(str)) {
			return str;
		}
		StringBuffer buf = new StringBuffer(str);
		while (buf.length() > 0 && buf.charAt(0) == leadingCharacter) {
			buf.deleteCharAt(0);
		}
		return buf.toString();
	}

	/**
	 * Trim all occurences of the supplied trailing character from the given String.
	 */
	public static String trimTrailingCharacter(String str, char trailingCharacter) {
		if (!hasLength(str)) {
			return str;
		}
		StringBuffer buf = new StringBuffer(str);
		while (buf.length() > 0 && buf.charAt(buf.length() - 1) == trailingCharacter) {
			buf.deleteCharAt(buf.length() - 1);
		}
		return buf.toString();
	}

	/**
	 * Test if the given String starts with the specified prefix, ignoring
	 * upper/lower case.
	 */
	public static boolean startsWithIgnoreCase(String str, String prefix) {
		if (str == null || prefix == null) {
			return false;
		}
		if (str.startsWith(prefix)) {
			return true;
		}
		if (str.length() < prefix.length()) {
			return false;
		}
		String lcStr = str.substring(0, prefix.length()).toLowerCase();
		String lcPrefix = prefix.toLowerCase();
		return lcStr.equals(lcPrefix);
	}

	/**
	 * Test if the given String ends with the specified suffix, ignoring upper/lower
	 * case.
	 */
	public static boolean endsWithIgnoreCase(String str, String suffix) {
		if (str == null || suffix == null) {
			return false;
		}
		if (str.endsWith(suffix)) {
			return true;
		}
		if (str.length() < suffix.length()) {
			return false;
		}

		String lcStr = str.substring(str.length() - suffix.length()).toLowerCase();
		String lcSuffix = suffix.toLowerCase();
		return lcStr.equals(lcSuffix);
	}

	/**
	 * Test whether the given string matches the given substring at the given index.
	 */
	public static boolean substringMatch(CharSequence str, int index, CharSequence substring) {
		for (int j = 0; j < substring.length(); j++) {
			int i = index + j;
			if (i >= str.length() || str.charAt(i) != substring.charAt(j)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Count the occurrences of the substring in string s
	 */
	public static int countOccurrencesOf(String str, String sub) {
		if (str == null || sub == null || str.length() == 0 || sub.length() == 0) {
			return 0;
		}
		int count = 0, pos = 0, idx = 0;
		while ((idx = str.indexOf(sub, pos)) != -1) {
			++count;
			pos = idx + sub.length();
		}
		return count;
	}

	/**
	 * 
	 * stringToLongArray(such as string "1,2,3,4" convert to LongArray")
	 * 
	 * TODO(Here describes this method to be suitable the condition - to be possible
	 * to elect)
	 * 
	 * @param str
	 * @return
	 * 
	 *         Long[]
	 */
	public static Long[] stringToLongArray(String str) {
		if (str != null && str.length() > 0) {
			String[] targetIdsArray = str.split(StringsUtils.COMMA);
			int arrayLength = targetIdsArray.length;
			Long[] targetIdsLongArray = new Long[arrayLength];
			for (int i = 0; i < arrayLength; i++) {
				targetIdsLongArray[i] = Long.parseLong(targetIdsArray[i]);
			}
			return targetIdsLongArray;
		} else {
			return null;
		}
	}

	/**
	 * 转半角的函数(DBC case)
	 * 全角空格为12288，半角空格为32 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
	 * @param input 任意字符串
	 * @return 半角字符串
	 *
	 */
	public static String toDbc(String input) {
		char[] c = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == 12288) {
				// 全角空格为12288，半角空格为32
				c[i] = (char) 32;
				continue;
			}
			if (c[i] > 65280 && c[i] < 65375) {
				// 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
				c[i] = (char) (c[i] - 65248);
			}
		}
		return new String(c);
	}

	/**
	 * 转全角的方法(SBC case)
	 * 全角空格为12288，半角空格为32 其他字符半角(33-126)与全角(65281-65374)的对应关系是：均相差65248
	 * @param input 任意字符串
	 * @return 半角字符串
	 *
	 */
	public static String toSbc(String input) {
		// 半角转全角：
		char[] c = input.toCharArray();
		for (int i = 0; i < c.length; i++) {
			if (c[i] == 32) {
				c[i] = (char) 12288;
				continue;
			}
			if (c[i] < 127) {
				c[i] = (char) (c[i] + 65248);
			}
		}
		return new String(c);
	}
	
	
	
    public static byte[] utf8Bytes(String data){
        try {
			return data.getBytes(CharsetConst.UTF8);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
    }

    public static String utf8String(byte[] data){
        try {
			return new String(data, CharsetConst.UTF8);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return null;
    }
	
    public static boolean inStringArray(String s, String[] array) {
        for (String x : array) {
            if (x.equals(s)) {
                return true;
            }
        }
        return false;
    }

	public static void main(String[] args) {
		System.out.println(StringsUtils.isNumeric("-null"));
		
		System.out.println(StringsUtils.toDbc("Ｈ１２３４５６"));
	}

}
