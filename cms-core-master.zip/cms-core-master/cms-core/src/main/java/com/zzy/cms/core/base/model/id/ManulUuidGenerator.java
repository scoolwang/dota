package com.zzy.cms.core.base.model.id;

import java.io.Serializable;

import org.hibernate.HibernateException;
import org.hibernate.engine.spi.SharedSessionContractImplementor;
import org.hibernate.id.UUIDGenerator;

/**
 *  自定义的主键生成策略，如果填写了主键id:  如果数据库中没有这条记录，则新增指定id的记录；     否则更新记录
 *  如果不填写主键id，则利用UUID指定id
 * @author guokaige
 */
public class ManulUuidGenerator extends UUIDGenerator{
 
    @Override
    public Serializable generate(SharedSessionContractImplementor s, Object obj) throws HibernateException {
        Serializable id = s.getEntityPersister(null, obj).getClassMetadata().getIdentifier(obj, s);
        if (id != null && id.toString().length() > 0) {
            return id;
        }
        return com.zzy.cms.core.util.UUIDGenerator.nextId();
    }

}