package com.zzy.cms.core.util.vaildatecode.processor;

import java.io.IOException;

import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.context.request.ServletWebRequest;

/**
 * 
 * @author guokaige
 * @date: 2018年9月14日 下午5:04:59
 */
public interface ValidateCodeProcessor {

    public static final String PROCESSOR_SUFFIX = "CodeProcessorCms";

    public static final String SESSION_KEY_VALIDATE_CODE_PREFIX = "SESSION_KEY_VALIDATE_CODE_";

    
    /**
     * 
    * 生成验证码 
    * @Description: TODO 
    * @param request
    * @throws IOException
    * @throws ServletRequestBindingException void
    * @author Administrator
    * @date 2018年9月14日下午5:04:26
     */
    public void generate(ServletWebRequest request) throws IOException, ServletRequestBindingException;

}
