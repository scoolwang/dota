package com.zzy.cms.core.util.cache;

import java.util.concurrent.TimeUnit;

/**
 * 
 * @author guokaige
 *
 */
public interface TopCacheManager {
	
	
	/**
	 * 手动更新
	 */
	public void refresh();
	
	/**
	 * 放数据
	 * @param key
	 * @param value
	 * @return
	 */
	public boolean put(String key, String value);
	
	/**
	 * 带过期时间存数据
	 * @param key
	 * @param value
	 * @param cacheTime
	 * @param timeUnit
	 * @return
	 */
	public boolean put(String key, String value, long cacheTime, TimeUnit timeUnit);
	/**
	 * 获取缓存数据
	 * @param key
	 * @return
	 */
	public String get(String key) ;
	
	/**
	 * 手动清除缓存
	 * @param key
	 * @return
	 */
	public boolean remove(String key);

}
