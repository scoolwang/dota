package com.zzy.cms.core.constant;

/**
 * @author guokaige
 */
public class SessionConst {
	/**
	 * 用户在框架中Session名称
	 */
	public static final String SESSION_CMS_USER_KEY = "SESSION_CMS_USER_KEY";
	
	/**
	 * 用户Id
	 */
	public static final String SESSION_CMS_USER_ID_KEY = "SESSION_CMS_USER_ID_KEY";

	/**
	 * 验证码
	 */
	public static final String SESSION_VALIDATE_CODE_IMAGE_KEY = "SESSION_VALIDATE_CODE_IMAGE_KEY";
}
