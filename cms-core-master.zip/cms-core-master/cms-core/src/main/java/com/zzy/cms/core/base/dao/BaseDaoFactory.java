package com.zzy.cms.core.base.dao;

import java.io.Serializable;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.support.JpaRepositoryFactory;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.core.RepositoryInformation;
import org.springframework.data.repository.core.RepositoryMetadata;


/**
 * 
 * @author guokaige
 * @param <S>
 * @param <ID>
 */
public class BaseDaoFactory<S, ID extends Serializable> extends JpaRepositoryFactory {
	
    public BaseDaoFactory(EntityManager entityManager) {
        super(entityManager);
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	protected SimpleJpaRepository<?, ?> getTargetRepository(RepositoryInformation information,EntityManager entityManager) {
		return new BaseDaoImpl(information.getDomainType(), entityManager);
	}

	@Override
    protected Class<?> getRepositoryBaseClass(RepositoryMetadata metadata) {
        return BaseDao.class;
    }

}
