package com.zzy.cms.core.base.jpa.plus;

import java.util.Collection;
import java.util.List;
/**
 * 
 * @author kaige
 *
 */
public interface IQueryWrapper {

	/**
	 * 相等
	 * @param column
	 * @param value
	 * @return
	 */
	public QueryWrapper eq(String column, Object value);

	/**
	 * 不等
	 * @param column
	 * @param value
	 * @return
	 */
	public QueryWrapper ne(String column, Object value);

	/**
	 * 大于
	 * @param column
	 * @param value
	 * @return
	 */
	public QueryWrapper gt(String column, Object value);

	/**
	 * 大于等于
	 * @param column
	 * @param value
	 * @return
	 */
	public QueryWrapper ge(String column, Object value);

	/**
	 * 小于
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper lt(String propertyName, Object value);

	/**
	 * 小于等于
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper le(String propertyName, Object value);
	
	/**
	 * 是NULL
	 * @param propertyName
	 * @return
	 */
	public QueryWrapper isNull(String propertyName);
	
	/**
	 * 非null
	 * @param propertyName
	 * @return
	 */
	public QueryWrapper isNotNull(String propertyName);

	/**
	 * like
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper like(String propertyName, String value);
	
	/**
	 * notLike
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper notLike(String propertyName, String value);

	/**
	 * value%
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper leftLike(String propertyName, String value);
	
	/**
	 * %value
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper rightLike(String propertyName, String value);

	/**
	 * or  like
	 * @param propertyName
	 * @param values
	 * @return
	 */
	public QueryWrapper orLike(String propertyName, List<String> values);

	/**
	 * or 等于
	 * @param propertyNames
	 * @param values
	 * @return
	 */
	public QueryWrapper orEq(String propertyNames, List<Object> values); 
	

	/**
	 * or关联
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper or(String propertyName, Object value);
	
	/**
	 * 与前一个条件or关联
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper orSpace(String propertyName, Object value);
	

	/**
	 * 实现in
	 * @param propertyName
	 * @param value
	 * @return
	 */
	public QueryWrapper in(String propertyName, Collection<?> value);

	/**
	 * 之间
	 * @param propertyName
	 * @param left
	 * @param right
	 * @return
	 */
	public QueryWrapper between(String propertyName, Object left, Object right);
	
}
