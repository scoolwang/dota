package com.zzy.cms.core.util.bean;

import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Objects;

import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeansException;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;


/**
 * 
 * @author guokaige
 *
 */
public class BeanUtil extends org.springframework.beans.BeanUtils {  
  
  public static void copyProperties(Object source, Object target) throws BeansException {  
    Assert.notNull(source, "Source must not be null");  
    Assert.notNull(target, "Target must not be null");  
    Class<?> actualEditable = target.getClass();  
    PropertyDescriptor[] targetPds = getPropertyDescriptors(actualEditable);  
    for (PropertyDescriptor targetPd : targetPds) {  
      if (targetPd.getWriteMethod() != null) {  
        PropertyDescriptor sourcePd = getPropertyDescriptor(source.getClass(), targetPd.getName());  
        if (sourcePd != null && sourcePd.getReadMethod() != null) {  
          try {  
            Method readMethod = sourcePd.getReadMethod();  
            if (!Modifier.isPublic(readMethod.getDeclaringClass().getModifiers())) {  
              readMethod.setAccessible(true);  
            }  
            Object value = readMethod.invoke(source);  
            // 这里判断以下value是否为空 当然这里也能进行一些特殊要求的处理 例如绑定时格式转换等等  
            if (value != null) {  
              Method writeMethod = targetPd.getWriteMethod();  
              if (!Modifier.isPublic(writeMethod.getDeclaringClass().getModifiers())) {  
                writeMethod.setAccessible(true);  
              }  
              writeMethod.invoke(target, value);  
            }  
          } catch (Throwable ex) {  
            throw new FatalBeanException("Could not copy properties from source to target", ex);  
          }  
        }  
      }  
    }  
  }  
  
  
  
  
	/**
	 * 实例化对象
	 *
	 * @param clazz 类
	 * @param <T>   泛型标记
	 * @return 对象
	 */
	@SuppressWarnings("unchecked")
	public static <T> T newInstance(Class<?> clazz) {
		return (T) instantiateClass(clazz);
	}

	/**
	 * 实例化对象
	 *
	 * @param clazzStr 类名
	 * @param <T>      泛型标记
	 * @return 对象
	 */
	public static <T> T newInstance(String clazzStr) {
		try {
			Class<?> clazz = ClassUtil.forName(clazzStr, null);
			return newInstance(clazz);
		} catch (ClassNotFoundException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * 获取Bean的属性, 支持 propertyName 多级 ：test.user.name
	 *
	 * @param bean         bean
	 * @param propertyName 属性名
	 * @return 属性值
	 */
	@Nullable
	public static Object getProperty(@Nullable Object bean, String propertyName) {
		if (bean == null) {
			return null;
		}
		BeanWrapper beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(bean);
		return beanWrapper.getPropertyValue(propertyName);
	}

	/**
	 * 设置Bean属性, 支持 propertyName 多级 ：test.user.name
	 *
	 * @param bean         bean
	 * @param propertyName 属性名
	 * @param value        属性值
	 */
	public static void setProperty(Object bean, String propertyName, Object value) {
		Objects.requireNonNull(bean, "bean Could not null");
		BeanWrapper beanWrapper = PropertyAccessorFactory.forBeanPropertyAccess(bean);
		beanWrapper.setPropertyValue(propertyName, value);
	}


}  