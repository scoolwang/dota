package com.zzy.cms.core.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.zzy.cms.core.dto.CodeMsg;

/**
 * @author guokaige
 *
 */
public class GlobalException extends RuntimeException {

	private static final long serialVersionUID = -6879298763723247455L;

	private Logger log=LoggerFactory.getLogger(this.getClass());

	private String message;
	
	private CodeMsg codeMsg;

	private Exception exception;

	public GlobalException(CodeMsg codeMsg) {
		super();
		this.codeMsg = codeMsg;
		this.message = codeMsg.getMsg();
	}
	
	public GlobalException(CodeMsg codeMsg, Exception exception) {
		super();
		this.codeMsg = codeMsg;
		this.exception = exception;
		this.message = codeMsg.getMsg();
	}

	public GlobalException(String message, Exception exception) {
		super();
		this.message = message;
		this.exception = exception;
		this.codeMsg= new CodeMsg(message);
	}
	
	public GlobalException(String message) {
		super();
		this.message = message;
		this.codeMsg= new CodeMsg(message);
	}

	public Logger getLog() {
		return log;
	}

	public void setLog(Logger log) {
		this.log = log;
	}

	@Override
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CodeMsg getCodeMsg() {
		return codeMsg;
	}

	public void setCodeMsg(CodeMsg codeMsg) {
		this.codeMsg = codeMsg;
	}

	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}
	
	

}
