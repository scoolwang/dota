package com.zzy.cms.core.base.jpa.plus;

import lombok.Data;

/**
 * 
 * @author kaige
 *
 */
@Data
public class QueryWhere {

    private String key;

    private Object value;

    private Joiner joiner;

    private QueryOpt queryOpt;


    public QueryWhere () {

    }

    public QueryWhere (String key, Object value) {
        this(key,value,Joiner.AND,QueryOpt.EQUAL);
    }


    public QueryWhere (String key,Object value,Joiner joiner) {
        this(key,value,joiner,QueryOpt.EQUAL);
    }


    public QueryWhere (String key,Object value,Joiner joiner,QueryOpt queryOpt) {
        this.key = key;
        this.value = value;
        this.joiner= joiner;
        this.queryOpt = queryOpt;
    }
  
}
