package com.zzy.cms.core.base.jpa.plus;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.zzy.cms.core.util.string.StringPool;

import cn.hutool.core.lang.Assert;

/**
 * 
 * @author kaige
 *
 */
public class QueryWrapper implements IQueryWrapper{

	private List<QueryWhere> whereList = new ArrayList<>();

	@Override
	public QueryWrapper eq(String propertyName, Object val) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,val);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper ne(String propertyName, Object val) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,val,Joiner.AND,QueryOpt.NOT_EQUAL);
		whereList.add(queryWhere);
		return this;
	}
	
	
	@Override
	public QueryWrapper gt(String propertyName, Object val) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,val,Joiner.AND,QueryOpt.GREATER_THAN);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper ge(String propertyName, Object val) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,val,Joiner.AND,QueryOpt.GREATER_THAN_EQUAL);
		whereList.add(queryWhere);
		return this;
	}

	@Override
	public QueryWrapper lt(String propertyName, Object value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LESS_THAN);
		whereList.add(queryWhere);
		return this;
	}

	@Override
	public QueryWrapper le(String propertyName, Object value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LESS_THAN_EQUAL);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper isNull(String propertyName) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,null,Joiner.AND,QueryOpt.IS_NULL);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper isNotNull(String propertyName) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,null,Joiner.AND,QueryOpt.IS_NOT_NULL);
		whereList.add(queryWhere);
		return this;
	}

	@Override
	public QueryWrapper like(String propertyName, String value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		value = StringPool.PERCENT + value + StringPool.PERCENT;
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LIKE);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper notLike(String propertyName, String value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.NOT_LIKE);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper leftLike(String propertyName, String value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		value = value + StringPool.PERCENT;
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LIKE);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper rightLike(String propertyName, String value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		value = StringPool.PERCENT + value ;
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LIKE);
		whereList.add(queryWhere);
		return this;
	}

	@Override
	public QueryWrapper orLike(String propertyName, List<String> values) {
		Assert.isTrue(null!=values && !values.isEmpty(),"propertyNames must not be null");
		QueryWhere queryWhere = null;
		for(int i =0 ; i<values.size(); i++) {
			String value = values.get(i);
			if(i==0) {
				queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.LIKE);
			}else {
				queryWhere = new QueryWhere(propertyName,value,Joiner.OR_SPACE,QueryOpt.LIKE);
			}
			whereList.add(queryWhere);
		}
		return this;
	}

	@Override
	public QueryWrapper orEq(String propertyName, List<Object> values) {
		Assert.isTrue(null!=values && !values.isEmpty(),"propertyNames must not be null");
		QueryWhere queryWhere = null;
		for(int i =0 ; i<values.size(); i++) {
			Object value = values.get(i);
			if(i==0) {
				queryWhere = new QueryWhere(propertyName,value,Joiner.AND,QueryOpt.EQUAL);
			}else {
				queryWhere = new QueryWhere(propertyName,value,Joiner.OR_SPACE,QueryOpt.EQUAL);
			}
			whereList.add(queryWhere);
		}
		return this;
	}
	
	@Override
	public QueryWrapper or(String propertyName, Object value) {
		Assert.isTrue(null!=value,"value must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.OR,QueryOpt.EQUAL);
		whereList.add(queryWhere);
		return this;
	}
	
	
	
	

	@Override
	public QueryWrapper in(String propertyName, Collection<?> values) {
		Assert.isTrue(null!=values && !values.isEmpty(),"values must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,values,Joiner.AND,QueryOpt.IN);
		whereList.add(queryWhere);
		return this;
	}
	
	@Override
	public QueryWrapper between(String propertyName, Object left, Object right) {
		Assert.isTrue(null!=left && null!=right,"left and right value must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,new Object[]{left,right},Joiner.AND,QueryOpt.BETWEEN);
		whereList.add(queryWhere);
		return this;
	}


	@Override
	public QueryWrapper orSpace(String propertyName, Object value) {
		Assert.isTrue(StringUtils.isNotBlank(propertyName),"propertyName must not be null");
		QueryWhere queryWhere = new QueryWhere(propertyName,value,Joiner.AND_SPACE,QueryOpt.EQUAL);
		whereList.add(queryWhere);
		return null;
	}

	public List<QueryWhere> getWhereList() {
		return whereList;
	}

}
