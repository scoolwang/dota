package com.zzy.cms.core.constant;


/**
 * 
 * @author guokaige
 *
 */
public class PropertyConst {
	
	/**
	 * 属性id
	 */
    public static final String ID = "id";
    
    /**
     * 状态
     */
    public static final String STATE = "rowState";
    
    /**
     * 更新事件属性
     */
    public static final String UPDATE_TIME = "updateTime";
    
    /**
     * 创建时间属性
     */
    public static final String CREATE_TIME = "createTime";
    
    
    /**
     * 操作人属性
     */
    public static final String OPERATE_USERID = "operateUserId";
    

}
