package com.zzy.cms.core.constant;

/**
 * @author guokaige
 *
 */
public class StateConst{

	
    /**
     * 正常
     */
	public static final String ENABLE="01";

	/**
	 * 注销
	 */
	public static final String CANCEL = "02";

	/**
	 * 删除
	 */
	public static final String DELETE = "03";
	
	/**
	 * 不可用
	 */
	public static final String DISABLED = "04";

	/**
	 * 是
	 */
	public static final String Y = "Y";

	/**
	 * 否
	 */
	public static final String N = "N";
	
	
	/**
	 * 是
	 */
	public static final String TRUE = "true";

	/**
	 * 否
	 */
	public static final String FASLE = "false";
	
	
	
	/**
	 * 状态01
	 */
	public static final String STATE_01 = "01";
	
	/**
	 * 状态02
	 */
	public static final String STATE_02 = "02";
	
	
	/**
	 * 状态03
	 */
	public static final String STATE_03 = "03";
	
	/**
	 * 状态04
	 */
	public static final String STATE_04 = "04";


}
