package com.zzy.cms.core.dto;

import java.util.List;

/**
 * 
 * @author guokaige
 *
 */
public class TreeNodes {

	private String text;
	private String href;
	private String tags;
	private List<TreeNodes> nodes;
    
	private Boolean selectable; 

	private TreeState state;
	
	private String iconName;
	private String parentId;
	private String layer;

	public String getIconName() {
		return iconName;
	}

	public void setIconName(String iconName) {
		this.iconName = iconName;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}

	public String getTags() {
		return tags;
	}

	public void setTags(String tags) {
		this.tags = tags;
	}

	public List<TreeNodes> getNodes() {
		return nodes;
	}

	public void setNodes(List<TreeNodes> nodes) {
		this.nodes = nodes;
	}

	public Boolean getSelectable() {
		return selectable;
	}

	public void setSelectable(Boolean selectable) {
		this.selectable = selectable;
	}

	public TreeState getState() {
		return state;
	}

	public void setState(TreeState state) {
		this.state = state;
	}

}
