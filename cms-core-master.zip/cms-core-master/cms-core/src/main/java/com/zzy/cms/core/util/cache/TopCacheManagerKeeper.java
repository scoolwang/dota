package com.zzy.cms.core.util.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.TimeUnit;

import com.google.common.util.concurrent.ThreadFactoryBuilder;


/**
 * 
 * @author kaige
 *
 */
public class TopCacheManagerKeeper {
	
	
	/**
	 * 缓存Map对象
	 */
	private static ConcurrentHashMap<String, TopCacheManager> cacheManagerMap = new ConcurrentHashMap<String, TopCacheManager>();

	/**
	 * 线程工厂
	 */
	private static ThreadFactory namedThreadFactory = new ThreadFactoryBuilder().setNameFormat("TopCacheManagerKeeper-pool-%d").build();

	/**
	 *  通过静态方法创建ScheduledExecutorService的实例
	 */
	private static ScheduledExecutorService executorService = new ScheduledThreadPoolExecutor(1, namedThreadFactory);
	
	
	/**
	 * 创建定时任务每分钟清理一次缓存
	 * 
	 */
	static {
		executorService.schedule(new Runnable(){
			@Override
			public void run() {
				for(Map.Entry<String,TopCacheManager> entry : cacheManagerMap.entrySet()) {
					entry.getValue().refresh();
				}
			}
		}, 60, TimeUnit.SECONDS);
	}


	public static ConcurrentHashMap<String, TopCacheManager> getCacheManagerMap() {
		return cacheManagerMap;
	}






}
