package com.zzy.cms.core.dto;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.google.common.collect.Lists; 

/**
 * 
 * @author guokaige
 * @Date   2019年4月3日 上午9:43:50 
 * @param <T>
 */
public class PageBean<T>{
	
	
	private List<T> content = Lists.newArrayList();
	
	private Pageable pageable;
	
	private Long totalElements;
	
	private int totalPages;
	
	/**
	 * pageSize
	 */
	private int size;
	
	/**
	 * pageNum
	 */
	private int number;
	
	private Sort sort;
	
	
	public PageBean(List<T> content, Pageable pageable, Long totalElements) {
		super();
		this.content = content;
		this.pageable = pageable;
		this.totalElements = totalElements;
		
		this.sort = pageable.getSort();
		this.number=pageable.getPageNumber();
		this.size = pageable.getPageSize();
		this.totalPages=(int) (totalElements%size>0?(int)(totalElements/size)+1:totalElements/size);
	}


	public List<T> getContent() {
		return content;
	}


	public void setContent(List<T> content) {
		this.content = content;
	}


	public Pageable getPageable() {
		return pageable;
	}


	public void setPageable(Pageable pageable) {
		this.pageable = pageable;
	}


	public int getSize() {
		return size;
	}


	public void setSize(int size) {
		this.size = size;
	}


	public Long getTotalElements() {
		return totalElements;
	}


	public void setTotalElements(Long totalElements) {
		this.totalElements = totalElements;
	}


	public int getTotalPages() {
		return totalPages;
	}


	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}


	public int getNumber() {
		return number;
	}


	public void setNumber(int number) {
		this.number = number;
	}


	public Sort getSort() {
		return sort;
	}


	public void setSort(Sort sort) {
		this.sort = sort;
	}
	
	
	
	
	
	

}