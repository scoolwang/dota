package com.zzy.cms.core.base.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.zzy.cms.core.base.dao.BaseDao;
import com.zzy.cms.core.base.jpa.plus.QueryWrapper;
import com.zzy.cms.core.constant.StateConst; 

/**
 * 
 * @author guokaige
 * @Date   2019年3月27日 上午8:36:55 
 * @param <T>
 * @param <PK>
 */
public abstract class BaseServiceImpl<T, ID extends Serializable> implements BaseService<T, ID> {

	protected Logger logger = LoggerFactory.getLogger(getClass());
 
	/**
	 * 在子类实现此函数,为下面的CRUD操作提供DAO.
	 * @return
	 */
	protected abstract BaseDao<T, ID> getEntityDao();

	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> S save(S entity) {
		return getEntityDao().save(entity);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> S saveWithId(S entity) {
		return getEntityDao().saveWithId(entity);
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> S saveOrUpdate(S entity) {
		return getEntityDao().saveOrUpdate(entity);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> S saveAndFlush(S entity) {
		return getEntityDao().saveAndFlush(entity);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> List<S> saveAll(Iterable<S> entities) {
		return getEntityDao().saveAll(entities);
	}

	
	@Override
	@Transactional(rollbackFor = Exception.class)
	public void deleteById(ID id) {
		getEntityDao().deleteById(id);
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public void deleteByIds(Iterable<ID> ids) {
		for(ID id : ids) {
			if(null!=id && !id.toString().isEmpty()) {
				getEntityDao().deleteById(id);
			}			
		}
	}

	@Override
	@Transactional(rollbackFor = Exception.class)
	public <S extends T> T update(ID id, S entity) {
		Assert.notNull(id, "The given id  must not be null!");
		T db = getEntityDao().update(id, entity);
		return db;
	}

	
	@Override
	public T findById(ID id) {
		return getEntityDao().findById(id).orElse(null);
	}
	
	@Override
	public T findEnableById(ID id) {
		QueryWrapper queryWrapper = new QueryWrapper();
		queryWrapper.eq("id", id);
		queryWrapper.eq("rowState", StateConst.ENABLE);
		List<T> list = getEntityDao().findByQueryWrapper(queryWrapper);
        if (null == list || list.isEmpty()) {
        	return null;
        }
        return list.get(0);
	}
	
	
	@Override
	public T findUniqueBy(final String propertyName, final Object value){
		return this.getEntityDao().findUniqueBy(propertyName, value);
	}
	
	@Override
	public <X> X findUniqueWithSql(String sql, Map<String, Object> params) {
		return this.getEntityDao().findUniqueWithSql(sql, params);
	}
	
	@Override
	public List<T> findByIds(Iterable<ID> ids) {
		return getEntityDao().findAllById(ids);
	}

	@Override
	public List<T> findAll() {
		return getEntityDao().findAll();
	}

	@Override
	public <S extends T> Optional<S> findOne(Example<S> example) {
		return getEntityDao().findOne(example);
	}

	@Override
	public <S extends T> Page<S> findAll(Example<S> example, Pageable pageable) {
		return getEntityDao().findAll(example, pageable);
	}

	@Override
	public List<T> findByQueryWrapper(QueryWrapper queryWrapper) {
		return getEntityDao().findByQueryWrapper(queryWrapper);
	}
	
	@Override
	public List<T> findSortByQueryWrapper(QueryWrapper queryWrapper, Sort sort) {
		return getEntityDao().findSortByQueryWrapper(queryWrapper, sort);
	}

	@Override
	public Page<T> findPageByQueryWrapper(QueryWrapper queryWrapper, Pageable pageable) {
		return getEntityDao().findPageByQueryWrapper(queryWrapper, pageable);
	}



}
