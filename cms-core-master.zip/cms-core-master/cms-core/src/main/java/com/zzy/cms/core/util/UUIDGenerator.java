package com.zzy.cms.core.util;

import java.util.UUID;

/**
 * 
 * @author guokaige
 *
 */
public class UUIDGenerator {
	
	public static String nextId() {
		return UUID.randomUUID().toString().replaceAll("-", "");
	}
	
}
