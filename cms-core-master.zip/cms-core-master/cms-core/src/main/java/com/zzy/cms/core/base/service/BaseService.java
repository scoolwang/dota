package com.zzy.cms.core.base.service;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.zzy.cms.core.base.jpa.plus.QueryWrapper; 

/**
 * 
 * @author guokaige
 * @Date   2019年3月27日 上午8:36:55 
 * @param <T>
 * @param <PK>
 */
public interface BaseService<T, ID extends Serializable> {
	
	/**
	 * 增
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param entity
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:11:54
	 */
	<S extends T> S save(S entity);
	
	
	/**
	 * 带Id保存
	 * @param <S>
	 * @param entity
	 * @return
	 */
	<S extends T> S saveWithId(S entity);
	
	
	/**
	 * 没Id就保存, 有ID,数据库有数据则更新, 数据库没数据就保存
	 * @param <S>
	 * @param entity
	 * @return
	 */
	<S extends T> S saveOrUpdate(S entity);
	
	/**
	 * 增并刷新内存
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param entity
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:12:06
	 */
	<S extends T> S saveAndFlush(S entity);

	/**
	 * jpa的批量保存
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param entities
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:12:45
	 */
	<S extends T> List<S> saveAll(Iterable<S> entities);
	

	
	/**
	 * 删
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:04
	 */
	void deleteById(ID id);
	
	/**
	 * 批量删除
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param ids    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:14
	 */
	void deleteByIds(Iterable<ID> ids);

	
	/**
	 * 更新
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id
	 * @param entity
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:25
	 */
	<S extends T> T update(ID id, S entity);

	/**
	 * 查
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:46
	 */
	T findById(ID id);
	
	
	/**
	 * 查
	 * @Title:        title
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:46
	 */
	T findEnableById(ID id);
	
	
	/**
	 * 按属性查找唯一对象, 匹配方式为相等.
	 * @param propertyName
	 * @param value
	 * @return
	 */
	T findUniqueBy(final String propertyName, final Object value);
	
	
    /**
     * 获取单条结果
     * @param <X>
     * @param sql
     * @param params
     * @return
     */
    <X> X findUniqueWithSql(String sql, Map<String, Object> params);
	
	/**
	 * 
	 * @Title:        批量查询
	 * @param ids
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:13:58
	 */
	List<T> findByIds(Iterable<ID> ids);

	/**
	 * 
	 * @Title:        查询全部
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:14:35
	 */
	List<T> findAll();

	/**
	 * 根据Example查询单个
	 * @Title:        title
	 * @param example
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:14:45
	 */
	<S extends T> Optional<S> findOne(Example<S> example);
	
	/**
	 * 
	 * @Title:        根据Example分页查询
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param example
	 * @param pageable
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:15:14
	 */
	<S extends T> Page<S> findAll(Example<S> example, Pageable pageable);
	
	
    
    /**
     * 通过wapper查询
     * @param queryWrapper
     * @return
     */
    List<T> findByQueryWrapper(QueryWrapper queryWrapper);
    
    /**
     * 通过wapper排序查询
     * @param queryWrapper
     * @param sort
     * @return
     */
    List<T> findSortByQueryWrapper(QueryWrapper queryWrapper, Sort sort);
    
    
    /**
     * 通过wapper分页查询
     * @param queryWrapper
     * @param pageable
     * @return
     */
    Page<T> findPageByQueryWrapper(QueryWrapper queryWrapper,Pageable pageable);
	
	



}
