package com.zzy.cms.core.base.jpa.plus;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author kaige
 *
 */
@Slf4j
public enum QueryOpt {

    /**
     *   1 模糊查询， 2 等于，3 不等于，4 between and  5 in,6 大于，7 大于等于 8 < 9 <=
     */
    LIKE(1), EQUAL(2), NOT_EQUAL(3), BETWEEN(4), IN(5),
    GREATER_THAN(6), GREATER_THAN_EQUAL(7), LESS_THAN(8) ,LESS_THAN_EQUAL(9), IS_NULL(10), IS_NOT_NULL(11), NOT_LIKE(12);

    int code;

    private QueryOpt(Integer code) {
        this.code = code;
    }

    public static QueryOpt ofNameOrValue(Object value) {
        if (value == null) {
            return QueryOpt.EQUAL;
        }
        if (Integer.class.isAssignableFrom(value.getClass()) || int.class.isAssignableFrom(value.getClass())) {
            return QueryOpt.valueOf((Integer) value);
        }
        try {
            return QueryOpt.valueOf((String) value);
        } catch (Exception ignored) {
        }
        try {
            return valueOf(Integer.parseInt((String) value));
        } catch (Exception e) {
            log.error("未能匹配枚举Operation ：", e);
        }
        return EQUAL;
    }

    public static QueryOpt valueOf(int value) {
        switch (value) {
            case 1:
                return LIKE;
            case 2:
                return EQUAL;
            case 3:
                return NOT_EQUAL;
            case 4:
                return BETWEEN;
            case 5:
                return IN;
            case 6:
                return GREATER_THAN;
            case 7:
                return GREATER_THAN_EQUAL;
            case 8:
                return LESS_THAN;
            case 9:
                return LESS_THAN_EQUAL;
            case 10:
                return IS_NULL;
            case 11:
                return IS_NOT_NULL; 
            case 12:
                return NOT_LIKE;       
            default:
                return null;
        }
    }
}
