package com.zzy.cms.core.base.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;

import com.fasterxml.jackson.annotation.JsonFormat;

import io.swagger.annotations.ApiModelProperty;

/**
 * 
 * @author guokaige
 *
 */
@MappedSuperclass
public class BaseModelEntity extends BaseEntity implements Serializable {

	private static final long serialVersionUID = 1L;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@Column(name = "CREATE_TIME")
	@ApiModelProperty(hidden = true)
	private Timestamp createTime;

	/**
	 * 更新时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@Column(name = "UPDATE_TIME")
	@ApiModelProperty(hidden = true)
	private Timestamp updateTime;

	/**
	 * 更新用户ID
	 */
	@Column(name = "OPERATE_USER_ID", length = 36)
	@ApiModelProperty(hidden = true)
	private String operateUserId;

	/**
	 * 01：正常；02：注销 ; 03: 删除; 04 不可用
	 */
	@Column(name = "ROW_STATE", length = 2)
	private String rowState = "01";
	
	
	
	
	

	public Timestamp getCreateTime() {
		return null == createTime ? null : (Timestamp)createTime.clone();
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = null == createTime ? null : (Timestamp)createTime.clone();
	}

	public Timestamp getUpdateTime() {
		return null == updateTime ? null : (Timestamp)updateTime.clone();
	}

	public void setUpdateTime(Timestamp updateTime) {
		this.updateTime = null == updateTime ? null : (Timestamp)updateTime.clone();
	}

	public String getOperateUserId() {
		return operateUserId;
	}

	public void setOperateUserId(String operateUserId) {
		this.operateUserId = operateUserId;
	}

	public String getRowState() {
		return rowState;
	}

	public void setRowState(String rowState) {
		this.rowState = rowState;
	}



}
