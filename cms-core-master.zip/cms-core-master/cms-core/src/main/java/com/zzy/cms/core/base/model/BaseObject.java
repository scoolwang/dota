package com.zzy.cms.core.base.model;

import java.io.Serializable;

import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.ToStringBuilder;

/**
 * @author guokaige
 */
@MappedSuperclass
public abstract class BaseObject implements Serializable {

	private static final long serialVersionUID = -3942149913171834745L;

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

}