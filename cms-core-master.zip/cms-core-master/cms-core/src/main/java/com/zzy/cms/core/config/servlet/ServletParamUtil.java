package com.zzy.cms.core.config.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;
import com.alibaba.fastjson.JSONObject;
import com.zzy.cms.core.constant.CharsetConst;

/**
 * 
 * @author kaige
 *
 */
public class ServletParamUtil {
	
     /**
      * 通用获取参数
      * @param request
      * @param paramName
      * @param defaultVal
      * @return
      */
	public static String getRequestParam(HttpServletRequest request, String paramName, String defaultVal) {
	    String paramValue = request.getHeader(paramName);
	    if(StringUtils.isBlank(paramValue)) {
	    	paramValue = request.getParameter(paramName);
	    }
		if(StringUtils.isBlank(paramValue)) {
			ServletInputStream  servletInputStream = null;
            BufferedReader streamReader = null ;
			try {
				servletInputStream = request.getInputStream();
				streamReader = new BufferedReader( new InputStreamReader(servletInputStream, CharsetConst.UTF8));
				StringBuilder responseStrBuilder = new StringBuilder();
				String inputStr;
				while ((inputStr = streamReader.readLine()) != null) {
					responseStrBuilder.append(inputStr);
				}
				JSONObject jsonObject = JSONObject.parseObject(responseStrBuilder.toString());
				paramValue = jsonObject.getString(paramName);
			} catch (Exception e) {
				e.printStackTrace();
			}finally {
				if(null != servletInputStream) {
					try {
						servletInputStream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
				if(null != streamReader){
                    try {
                        streamReader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
			}
		}
		if(StringUtils.isEmpty(paramValue)) {
			return defaultVal;
		}
		return paramValue;
	}

}
