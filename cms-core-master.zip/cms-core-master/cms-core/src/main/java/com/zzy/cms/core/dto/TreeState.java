package com.zzy.cms.core.dto;


/**
 * 
 * @author guokaige
 *
 */
public class TreeState {

	private Boolean checked;
	private Boolean disabled;
	private Boolean expanded;
	private Boolean selected;

	public TreeState(Boolean selected) {
		super();
		this.checked = true;
		this.disabled = false;
		this.expanded = true;
		this.selected = selected;
	}

	public TreeState(Boolean checked, Boolean disabled, Boolean expanded, Boolean selected) {
		super();
		this.checked = checked;
		this.disabled = disabled;
		this.expanded = expanded;
		this.selected = selected;
	}

	public Boolean getChecked() {
		return checked;
	}

	public void setChecked(Boolean checked) {
		this.checked = checked;
	}

	public Boolean getDisabled() {
		return disabled;
	}

	public void setDisabled(Boolean disabled) {
		this.disabled = disabled;
	}

	public Boolean getExpanded() {
		return expanded;
	}

	public void setExpanded(Boolean expanded) {
		this.expanded = expanded;
	}

	public Boolean getSelected() {
		return selected;
	}

	public void setSelected(Boolean selected) {
		this.selected = selected;
	}

}
