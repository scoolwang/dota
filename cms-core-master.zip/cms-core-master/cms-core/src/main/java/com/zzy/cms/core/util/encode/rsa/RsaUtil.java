package com.zzy.cms.core.util.encode.rsa;
import java.security.KeyPair;

import cn.hutool.core.util.HexUtil;
import cn.hutool.crypto.SecureUtil;
import cn.hutool.crypto.asymmetric.KeyType;
import cn.hutool.crypto.asymmetric.RSA;


/**
 * 
 * @author guokaige
 * @date: 2018年11月21日 下午3:31:47
 */
public  class RsaUtil {
	
	public static TopKeyPair generateKeyPair() {
		KeyPair pair = SecureUtil.generateKeyPair("RSA");
		return TopKeyPair.builder()
				.privateKey(HexUtil.encodeHexStr(pair.getPrivate().getEncoded()))
				.publicKey(HexUtil.encodeHexStr(pair.getPublic().getEncoded()))
				.build();
	}
	
	public static String encryptByPrivateKey(String privateKey, String content) {
		byte[] priKey = HexUtil.decodeHex(privateKey);
		RSA rsa = new RSA(priKey,null);
		String encoreStr = rsa.encryptBcd(content, KeyType.PrivateKey);
		return encoreStr;
	}
	
	public static String decodeByPrivateKey(String privateKey, String encoreStr) {
		byte[] priKey = HexUtil.decodeHex(privateKey);
		RSA rsa = new RSA(priKey,null);
		String content = rsa.decryptStr(encoreStr, KeyType.PrivateKey);
		return content;
	}
	
	
	public static String encryptByPublicKey(String publicKey, String content) {
		byte[] pubKey = HexUtil.decodeHex(publicKey);
		RSA rsa = new RSA(null,pubKey);
		String encoreStr = rsa.encryptBcd(content, KeyType.PublicKey);
		return encoreStr;
	}
	
	public static String decodeByPublicKey(String publicKey, String encoreStr) {
		byte[] pubKey = HexUtil.decodeHex(publicKey);
		RSA rsa = new RSA(null,pubKey);
		String content = rsa.encryptBcd(encoreStr, KeyType.PublicKey);
		return content;
	}
    
    public static void main(String[] args) {
    	
    	TopKeyPair topKeyPair = RsaUtil.generateKeyPair();
    	
    	String encodeStr = RsaUtil.encryptByPublicKey(topKeyPair.getPublicKey(), "gkg测试1234567890");
    	System.out.println("公钥加密后:"+encodeStr);
    	
    	String content = RsaUtil.decodeByPrivateKey(topKeyPair.getPrivateKey(), encodeStr);
    	System.out.println("私钥解密后:"+content);
	}
}