package com.zzy.cms.core.constant;

/**
 * 
 * @author guokaige
 *
 */
public class HttpConst {



    /**
     * HTTP协议头
     */
    public static final String INTERNET_PREFIX_HTTP = "http://";
    /**
     * HTTPS协议头
     */
    public static final String INTERNET_PREFIX_HTTPS = "https://";
    /**
     * 内容类型KEY
     */
    public static final String RESPONSE_CONTENT_TYPE = "Content-type";
    /**
     * HTML响应内容类型
     */
    public static final String RESPONSE_CONTENT_TYPE_HTML = "text/html;charset=utf-8";
    /**
     * CSS响应内容类型
     */
    public static final String RESPONSE_CONTENT_TYPE_CSS = "text/css;charset=utf-8";
    /**
     * JS响应内容类型
     */
    public static final String RESPONSE_CONTENT_TYPE_JS = "text/javascript;charset=utf-8";
    /**
     * JSON响应内容类型
     */
    public static final String RESPONSE_CONTENT_TYPE_JSON = "application/json;charset=UTF-8";
    /**
     * JPEG响应内容类型
     */
    public static final String RESPONSE_CONTENT_TYPE_JPEG = "image/jpeg";
    /**
     * Accept-Ranges 字符串值属性的响应头信息
     */
    public static final String RESPONSE_HEADER_NAME_ACCEPT_RANGS = "Accept-Ranges";
    /**
     * Accept-Ranges 字符串值属性的响应头信息值：bytes
     */
    public static final String RESPONSE_HEADER_VALUE_BYTES = "bytes";
    /**
     * Pragma 字符串值属性的响应头信息
     */
    public static final String RESPONSE_HEADER_NAME_PRAGMA = "Pragma";
    /**
     * Pragma 字符串值属性的响应头信息值：No-cache
     */
    public static final String RESPONSE_HEADER_VALUE_NOCACHE = "no-cache";
    /**
     * Cache-Control 字符串值属性的响应头信息
     */
    public static final String RESPONSE_HEADER_NAME_CACHECONTROL = "Cache-Control";
    /**
     * Expires 时间值属性的响应头信息
     */
    public static final String RESPONSE_DATE_HEADER_NAME_EXPIRES = "Expires";
    /**
     *  GET请求方式
     */
    public static final String REQUEST_METHOD_GET = "GET";
    /**
     *  POST请求方式
     */
    public static final String REQUEST_METHOD_POST = "GET";
    /**
     *  PUT请求方式
     */
    public static final String REQUEST_METHOD_PUT = "PUT";
    /**
     *  DELETE请求方式
     */
    public static final String REQUEST_METHOD_DELETE = "DELETE";
    /**
     *  HEAD请求方式
     */
    public static final String REQUEST_METHOD_HEAD = "HEAD";
    /**
     *  HEAD请求方式
     */
    public static final String PARAMETER_CONNECTOR_QUESTION = "?";
    /**
     *  HEAD请求方式
     */
    public static final String PARAMETER_CONNECTOR_AND = "&";
    /**
     *  HEAD请求方式
     */
    public static final String CONNECT_TYPE_JSONP = "jsonp";
    
    
    /**
       *   请求后缀
      */
    public static final String REQUEST_URL_SUFFIX_ACTION = ".action";
    
    /**
	     *   请求后缀
	  */
	public static final String REQUEST_URL_SUFFIX_JSON = ".json";
	
    /**
	     *   请求后缀
	  */
	public static final String REQUEST_URL_SUFFIX_PAGE = ".page";



}
