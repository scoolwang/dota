package com.zzy.cms.core.util.encode;

import java.io.UnsupportedEncodingException;
import java.util.Base64;


/**
 * 
 * @author guokaige
 *
 */
public class Base64EncodeUtil {
	
	
	/** 
     * @param bytes 
     * @return 
     */  
    public static byte[] decode(String content) {  
        return Base64.getDecoder().decode(content);  
    } 
    
  
    /** 
     * 二进制数据编码为BASE64字符串 
     * 
     * @param bytes 
     * @return 
     * @throws Exception 
     */  
    public static String encode(byte[] content) {  
        return Base64.getEncoder().encodeToString(content);
    }  
    
    
    
    
    public static void main(String[] args) throws UnsupportedEncodingException {
    	
    	
    	
    	String asB64 = Base64.getEncoder().encodeToString("郭凯歌123413wrewfsdf".getBytes("utf-8"));  
    	// 输出为: c29tZSBzdHJpbmc=  
    	System.out.println(asB64); 
    	   
    	// 解码  
    	byte[] asBytes = Base64.getDecoder().decode(asB64);  
    	// 输出为: some string  
    	System.out.println(new String(asBytes, "utf-8")); 
	}

}
