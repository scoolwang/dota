package com.zzy.cms.core.util.map;

import java.beans.BeanInfo;
import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;


/**
 * 
 * @author guokaige
 *
 */
public class MapUtil {


	/**
	 * 把JavaBean转化为map
	 * @param bean
	 * @return
	 */
	public static Map<String, Object> bean2map(Object bean){
		Map<String, Object> map = new HashMap<>(16);
		try {
			// 获取JavaBean的描述器
			BeanInfo b = Introspector.getBeanInfo(bean.getClass(), Object.class);
			// 获取属性描述器
			PropertyDescriptor[] pds = b.getPropertyDescriptors();
			// 对属性迭代
			for (PropertyDescriptor pd : pds) {
				// 属性名称
				String propertyName = pd.getName();
				// 属性值,用getter方法获取
				Method m = pd.getReadMethod();
				// 用对象执行getter方法获得属性值
				Object properValue = m.invoke(bean);
				// 把属性名-属性值 存到Map中
				map.put(propertyName, properValue);
			}
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (IntrospectionException e) {
			e.printStackTrace();
		}
		return map;
	}


	/**
	 * 把Map转化为JavaBean
	 * @param map
	 * @param clz
	 * @param <T>
	 * @return
	 */
	public static <T> T map2bean(Map<String, Object> map, Class<T> clz){
		// 创建一个需要转换为的类型的对象
		T obj = null;
		try {
			obj = clz.newInstance();

			// 得到属性的描述器
			BeanInfo b = Introspector.getBeanInfo(clz, Object.class);
			PropertyDescriptor[] pds = b.getPropertyDescriptors();
			for (PropertyDescriptor pd : pds) {
				// 得到属性的setter方法
				Method setter = pd.getWriteMethod();
				// 得到key名字和属性名字相同的value设置给属性
				setter.invoke(obj, map.get(pd.getName()));
			}
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		} catch (IntrospectionException e) {
			e.printStackTrace();
		}
		return obj;
	}

}
