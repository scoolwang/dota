package com.zzy.cms.core.util.http;

import java.util.Map;
import java.util.Map.Entry;

import com.zzy.cms.core.constant.NumberConst;
import com.zzy.cms.core.util.CollectionUtil;
import com.zzy.cms.core.util.string.StringsUtils;

import jodd.http.HttpBrowser;
import jodd.http.HttpRequest;
import jodd.http.HttpResponse;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author guokaige
 *
 */
@Slf4j
public class JoddHttpUtil {
	
	public static String post(String serverUrl, Map<String, Object> params) {
		return JoddHttpUtil.post(serverUrl, params, null, NumberConst.NUM_10000);
	}
	
	public static String post(String serverUrl, Map<String, Object> params,Map<String, Object> headers) {
		return JoddHttpUtil.post(serverUrl, params, headers, NumberConst.NUM_10000);
	}

	public static String post(String serverUrl, Map<String, Object> params, Map<String, Object> headers, int milliseconds) {
		// POST请求
		HttpResponse response = null;
		String result = null;
		try {
			HttpRequest httpRequest = HttpRequest.post(serverUrl).form(params).timeout(milliseconds).queryEncoding("utf-8");
			if(CollectionUtil.isNotEmpty(headers)) {
				for(Entry<String, Object> entry : headers.entrySet()) {
					httpRequest.header(entry.getKey(), entry.getValue().toString());
				}
			}
			response = httpRequest.send();
			result = response.body();
			if(StringsUtils.hasNotText(result)) {
				result= String.format("远程访问接口%s,参数:%s,异常%s", serverUrl, params, "返回结果为空");
			}
			result = new String(result.getBytes("iso8859-1"),"utf-8");
			return result;
		} catch (Exception e) {
			result= String.format("远程访问接口%s,参数:%s,异常%s", serverUrl, params, e);
			log.error("远程访问接口{},参数:{},异常{}", serverUrl, params, e);
		}
		return result;
	}
	
	public static String get(String serverUrl) {
		return JoddHttpUtil.get(serverUrl,null , null, NumberConst.NUM_10000);
	}
	
	public static String get(String serverUrl, Map<String, Object> headers) {
		return JoddHttpUtil.get(serverUrl, null , headers, NumberConst.NUM_10000);
	}
	
	public static String get(String serverUrl, Map<String, String> params, Map<String, Object> headers) {
		return JoddHttpUtil.get(serverUrl, params , headers, NumberConst.NUM_10000);
	}

	public static String get(String serverUrl, Map<String, String> params, Map<String, Object> headers, int milliseconds) {
		// get请求
		HttpResponse response = null;
		String result = null;
		try {
			HttpRequest httpRequest = HttpRequest.get(serverUrl).timeout(milliseconds).queryEncoding("utf-8");
			if(CollectionUtil.isNotEmpty(params)) {
				    httpRequest.query(params);
			}
			if(CollectionUtil.isNotEmpty(headers)) {
				for(Entry<String, Object> entry : headers.entrySet()) {
					httpRequest.header(entry.getKey(), entry.getValue().toString());
				}
			}
			response = httpRequest.send();
			result = response.body();
			result = new String(result.getBytes("iso8859-1"),"utf-8");
			return result;
		} catch (Exception e) {
			result= String.format("远程访问接口%s,异常%s", serverUrl, e);
			log.error("远程访问接口{},异常{}", serverUrl, e);
		}
		return result;
	}
	
	
	
	
	
	public static String post(String url, String jsonParams) {
		return JoddHttpUtil.post(url, jsonParams, NumberConst.NUM_10000);
	}
	

	/**
	 * 发送Post请求-json数据
	 * 
	 * @param url    : 请求的连接
	 * @param params ： 请求参数，无参时传null
	 * @return
	 */
	public static String post(String url, String jsonParams, int milliseconds) {
		String result =null;
		
		HttpRequest request = HttpRequest.post(url);
		request.contentType("application/json");
		request.charset("utf-8");

		// 参数详情
		if (StringsUtils.hasText(jsonParams)) {
			request.body(jsonParams);
		}

		HttpResponse response = null;
		try {
			response = request.timeout(milliseconds).queryEncoding("utf-8").send();
			result = response.body();
			result = new String(result.getBytes("iso8859-1"),"utf-8");
			return result;
		} catch (Exception e) {
			result= String.format("远程访问接口%s, 参数:%s,异常%s", url, jsonParams, e);
			log.error("远程访问接口{},参数:{},异常{}", url, jsonParams, e);
		}
		return result;
	}
	
	/**
	 * 模擬瀏覽器
	 * @param serverUrl
	 * @return
	 */
	public static String browseUrl(String serverUrl) {
		HttpBrowser browser = new HttpBrowser();
		HttpRequest request = HttpRequest.get(serverUrl).timeout(NumberConst.NUM_10000).queryEncoding("utf-8");
		try {
			browser.sendRequest(request);
		} catch (Exception e) {
			log.error("远程访问接口{},异常{}", serverUrl, e);
		}
		String pageText = browser.getPage();
		return pageText;
	}
}
