package com.zzy.cms.core.base.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;
import org.springframework.util.Assert;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Controller 基类
 * @author guokaige
 * @since 3.0
 */
public class BaseController {
	
	
    /**
     * 包装分页对象
     *
     * @param pageNo 页码
     * @param pageSize
     * @return
     */
    public PageRequest wrapPageable(Integer pageNo, Integer pageSize) {
    	if (null == pageNo || pageNo < 1) {
        	pageNo = 1;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize = 10;
        }
        return PageRequest.of(pageNo-1, pageSize);
    }
    
    /**
     * 包装分页排序对象
     * @param pageNo
     * @param pageSize
     * @param sort
     * @return
     */
    public PageRequest wrapPageable(Integer pageNo, Integer pageSize, Sort sort) {
    	if (null == pageNo || pageNo < 1 ) {
        	pageNo = 1;
        }
        if (pageSize == null || pageSize == 0) {
            pageSize = 10;
        }
        return PageRequest.of(pageNo - 1, pageSize, sort);
    }
    
    
	/**
	 * 封装分页
	 * @return
	 */
    public PageRequest wrapPageable(Sort sort) {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Integer pageSize = ServletRequestUtils.getIntParameter(request, "pageSize", 5);
        Integer pageNo = ServletRequestUtils.getIntParameter(request, "pageNumber", 1);
        return PageRequest.of(pageNo - 1, pageSize, sort);
    }

	/**
	 * 封装分页
	 * @return
	 */
    public PageRequest wrapPageable() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        Integer pageSize = ServletRequestUtils.getIntParameter(request, "pageSize", 5);
        Integer pageNo = ServletRequestUtils.getIntParameter(request, "pageNumber", 1);
        
        Sort sort = Sort.unsorted();
        List<Order> orderList = this.handleSort();
        if (null!= orderList && !orderList.isEmpty()) {
            sort = Sort.by(orderList);
        }
        return PageRequest.of(pageNo - 1, pageSize, sort);
    }

    /**
     * 处理多重排序
     * @return
     */
    public List<Order> handleSort(){
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
        String propertys = ServletRequestUtils.getStringParameter(request, "propertys", "");
        String directions = ServletRequestUtils.getStringParameter(request, "directions", "");
        String[] propertysArray = StringUtils.split(propertys, ',');
		String[] directionsArray = StringUtils.split(directions, ',');
		Assert.isTrue(propertysArray.length == directionsArray.length, "分页多重排序参数中,排序字段与排序方向的个数不相等");
		List<Order> orders = new ArrayList<Order>(); ;
		for (int i = 0; i < propertysArray.length; i++) {
			Assert.isTrue(StringUtils.isNotBlank(propertysArray[i]), "分页多重排序参数中,排序字段不能为空!");
			if (Direction.DESC.toString().equalsIgnoreCase(directionsArray[i])) {
				orders.add(new Order(Direction.DESC,propertysArray[i]));
			} else {
				orders.add(new Order(Direction.ASC,propertysArray[i]));
			}
		}
		return orders;
    }


}
