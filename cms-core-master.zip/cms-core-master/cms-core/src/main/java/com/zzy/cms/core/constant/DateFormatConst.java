package com.zzy.cms.core.constant;


/**
 * 
 * @author liuchaojie
 *
 */
public class DateFormatConst {
	
	
	public static final String  DATE ="yyyy-MM-dd";
	
	public static final String  DATE_TIME ="yyyy-MM-dd HH:mm:ss";
	
	public static final String  TIME ="HH:mm:ss";
	
	public static final String  DAY_FIRST_SECOND =" 00:00:00";
	
	public static final String  DAY_LAST_SECOND =" 23:59:59";
	
	public static final String  DATE_HOUR ="yyyy-MM-dd HH";
	

}
