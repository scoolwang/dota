/**
 * 
 */
package com.zzy.cms.core.util;

import java.lang.reflect.Method;
import java.sql.Timestamp;

import com.zzy.cms.core.exception.BizException;


/**
 * @author zhuhuidong
 *
 */
public class OperationUtil{
	
	
	
	/**
	 * 记录创建操作
	 * @param object
	 * @param userId
	 */
	public static void writeCreateOperation(Object object, String userId){
		Class<? extends Object> objClass = object.getClass().getSuperclass();
		
		try {
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			Method setCreateTimeMethod = objClass.getMethod("setCreateTime", Timestamp.class);
			setCreateTimeMethod.invoke(object, timestamp);
			
			Method setUpdateTimeMethod = objClass.getMethod("setUpdateTime", Timestamp.class);
			setUpdateTimeMethod.invoke(object, timestamp);
			
			Method setUserIdMethod = objClass.getMethod("setOperateUserId", String.class);
			setUserIdMethod.invoke(object, userId);
		} catch (Exception e) {
			throw new BizException("OperationUtils-->writeOperation异常", e);
		}
	}
	
	/**
	 * 记录更新操作
	 * @param object
	 * @param userId
	 */
	public static void writeUpdateOperation(Object object, String userId){
		Class<? extends Object> objClass = object.getClass().getSuperclass();
		
		try {
			Method setTimeMethod = objClass.getMethod("setUpdateTime", Timestamp.class);
			setTimeMethod.invoke(object, new Timestamp(System.currentTimeMillis()));
			
			Method setUserIdMethod = objClass.getMethod("setOperateUserId", String.class);
			setUserIdMethod.invoke(object, userId);
		} catch (Exception e) {
			throw new BizException("OperationUtils-->writeOperation异常", e);
		}
	}
}
