package com.zzy.cms.core.util.vaildatecode.processor;

import java.io.IOException;

import org.springframework.web.bind.ServletRequestBindingException;
import org.springframework.web.context.request.ServletWebRequest;

import com.zzy.cms.core.util.vaildatecode.ValidateCode;

/**
 * 
 * @author guokaige
 * @date: 2018年10月11日 下午2:46:57
 */
public abstract class BaseDefaultValidateCodeProcessor implements ValidateCodeProcessor {


    @Override
    public final void generate(ServletWebRequest request) throws IOException, ServletRequestBindingException {
        ValidateCode validateCode = generateCode(request);
        send(request, validateCode);
    }

    /**
     * 
    * 生成验证码 
    * @Description: TODO 
    * @param request
    * @return ValidateCode
    * @author Administrator
    * @date 2018年9月14日下午5:03:45
     */
    public abstract ValidateCode generateCode(ServletWebRequest request);

    
    /**
     * 
    * 发送验证码 
    * @Description: TODO 
    * @param request
    * @param validateCode
    * @throws IOException
    * @throws ServletRequestBindingException void
    * @author Administrator
    * @date 2018年9月14日下午5:04:04
     */
    public abstract void send(ServletWebRequest request, ValidateCode validateCode) throws IOException, ServletRequestBindingException;

}
