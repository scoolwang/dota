package com.zzy.cms.core.base.jpa.plus;


import java.beans.PropertyDescriptor;
import java.lang.reflect.Method;
import java.util.Collection;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.query.criteria.internal.ValueHandlerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.data.jpa.domain.Specification;

/**
 * 
 * @author kaige
 *
 * @param <T>
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
public class SpecificationUtils<T> {

    private static final int BETWEEN_LENGTH = 2;

    private final Class<T> domainClass;

	public SpecificationUtils(Class domainClass) {
        this.domainClass = domainClass;
    }


	public Specification<T> toPredicate(List<QueryWhere> wheres) {

        return new Specification<T>() {
			private static final long serialVersionUID = -5157988801212627993L;

			@Override
            public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
                return parseWheres(root,cb,wheres);
            }
        };

    }

    private Predicate parseWheres(Root<T> root, CriteriaBuilder cb, List<QueryWhere> wheres) {


        Predicate predicate = null;
        Predicate tempPredicate = null;
        Joiner tempJoiner = null;
        for (QueryWhere v : wheres) {
        	QueryOpt queryOpt = v.getQueryOpt();
            String key = v.getKey();
            Object value = v.getValue();
            if (StringUtils.isEmpty(key)) {
                throw new IllegalArgumentException(String.format("无效的参数 key = %s", key));
            }

            if (value == null || "".equals(value)) {
            	if(QueryOpt.IS_NULL != queryOpt && QueryOpt.IS_NOT_NULL != queryOpt) {
            		throw new IllegalArgumentException(String.format("非法的参数value  = %s:%s", key, value));
            	}
            }

            Joiner joiner = v.getJoiner();
            if (joiner == null) {
                joiner = Joiner.AND;
            }

            if (queryOpt == null) {
                queryOpt = QueryOpt.EQUAL;
            }

            // 数据类型不匹配时，进行转换
            if ( QueryOpt.IN != queryOpt && 
            		QueryOpt.BETWEEN != queryOpt && 
            		QueryOpt.IS_NULL != queryOpt && 
            		QueryOpt.IS_NOT_NULL != queryOpt) {
                value = convertValue(key, value);
            }

            Predicate p = createPredicate(cb, root, queryOpt, v);

            switch (v.getJoiner()) {
                case AND:
                case OR:
                    if (predicate == null) {
                        predicate = tempPredicate;
                    } else {
                        if (tempJoiner == Joiner.OR) {
                            predicate = cb.or(predicate, tempPredicate);
                        } else {
                            predicate = cb.and(predicate, tempPredicate);
                        }
                    }
                    tempPredicate = p;
                    tempJoiner = joiner;
                    break;
                case AND_SPACE:
                    tempPredicate = cb.and(tempPredicate, p);
                    break;
                case OR_SPACE:
                    tempPredicate = cb.or(tempPredicate, p);
                    break;
                default:
                    throw new IllegalArgumentException("无效的参数 joiner" + v.getJoiner());
            }
        }

        if (predicate == null) {
            return tempPredicate;
        }
        if (tempJoiner == Joiner.OR) {
            return cb.or(predicate, tempPredicate);
        }
        return cb.and(predicate, tempPredicate);
    }

	private Predicate createPredicate(CriteriaBuilder cb, Root root, QueryOpt queryOpt, QueryWhere queryWhere) {
        Path path = root.get(queryWhere.getKey());
        Object value = queryWhere.getValue();
        switch (queryOpt) {
            case EQUAL:
                return cb.equal(path, value);
            case NOT_EQUAL:
                return cb.notEqual(path, value);    
            case GREATER_THAN:
                return cb.greaterThan(path, (Comparable) value);
            case LESS_THAN:
                return cb.lessThan(path, (Comparable) value);
            case LIKE:
                return cb.like(path, value+"");   
            case NOT_LIKE:
                return cb.notLike(path, value+"");      
            case GREATER_THAN_EQUAL:
                return cb.greaterThanOrEqualTo(path, (Comparable) value);
            case LESS_THAN_EQUAL:
                return cb.lessThanOrEqualTo(path, (Comparable) value);
            case IS_NULL:
                return cb.isNull(path);
            case IS_NOT_NULL:
                return cb.isNotNull(path);    
            case IN:
                return path.in(((Collection) value).toArray());
            case BETWEEN:
                Object[] arr = ( Object[]) value;
                if (arr.length != BETWEEN_LENGTH) {
                    throw new IllegalArgumentException("操作符 between 格式不正确");
                }
                Object start = convertValue(queryWhere.getKey(), arr[0]);
                Object end = convertValue(queryWhere.getKey(), arr[1]);
                return cb.between(path, (Comparable) start, (Comparable) end);
            default:
                throw new IllegalArgumentException("无效的操作类型" + queryWhere.getQueryOpt());
        }
    }

    /**
     * @param fieldName
     * @return
     */
    private Method getGetMethod(String fieldName) {
        PropertyDescriptor pd = BeanUtils.getPropertyDescriptor(domainClass, fieldName);
        return pd == null ? null : pd.getReadMethod();
    }

    /**
     * 校验类型是否是一样的。
     *
     * @param fieldName 传入的key
     * @param value     属性名
     * @return
     */
    private Object convertValue(String fieldName, Object value) {
        Method method = getGetMethod(fieldName);
        if (method == null) {
            return null;
        }
        if (!method.getReturnType().isAssignableFrom(value.getClass())) {
        	value = ValueHandlerFactory.convert(value, method.getReturnType());
        }
        return value;
    }

}
