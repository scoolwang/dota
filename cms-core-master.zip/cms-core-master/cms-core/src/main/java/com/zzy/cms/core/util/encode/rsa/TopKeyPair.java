package com.zzy.cms.core.util.encode.rsa;

import lombok.Builder;
import lombok.Data;


/**
 * 
 * @author kaige
 *
 */
@Data
@Builder
public class TopKeyPair implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	private String privateKey;
    private String publicKey;

}
