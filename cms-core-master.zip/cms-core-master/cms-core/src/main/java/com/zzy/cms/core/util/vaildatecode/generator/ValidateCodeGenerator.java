package com.zzy.cms.core.util.vaildatecode.generator;

import javax.servlet.http.HttpServletRequest;

import com.zzy.cms.core.util.vaildatecode.ValidateCode;

/**
 * 
 *  @author guokaige
 *
 */
public interface ValidateCodeGenerator {

	
	/**
	 * 生成验证码
	* @Title: generate 
	* @Description: TODO 
	* @param request
	* @return ValidateCode
	* @author Administrator
	* @date 2018年9月14日下午5:03:10
	 */
    public ValidateCode generate(HttpServletRequest request);
}
