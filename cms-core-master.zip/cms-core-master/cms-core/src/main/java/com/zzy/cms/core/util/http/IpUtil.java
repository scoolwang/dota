package com.zzy.cms.core.util.http;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import com.zzy.cms.core.util.string.StringsUtils;

/**
 * 
 * @author guokaige
 *
 */
public final class IpUtil {

	private final static String STATUS_UNKONOW = "unknown";
	
	private final static Integer IP_LENGTH = 15;
	
	public final static String LOCAL_NOT_IP = "0:0:0:0:0:0:0:1"; 
	
	public final static String LOCAL_IP = "127.0.0.1"; 

	/**
	 * 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址;
	 * 
	 * @param request
	 * @return
	 * @throws IOException
	 */
	public static String getIp(HttpServletRequest request){
		// 获取请求主机IP地址,如果通过代理进来，则透过防火墙获取真实IP地址

		String ip = request.getHeader("X-Real-IP");
		
		if (StringsUtils.hasText(ip) && !STATUS_UNKONOW.equalsIgnoreCase(ip)) {
			return ip;
		}
		
		ip = request.getHeader("X-Forwarded-For");

		if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
			if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
				ip = request.getHeader("Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
				ip = request.getHeader("WL-Proxy-Client-IP");
			}
			if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_CLIENT_IP");
			}
			if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
				ip = request.getHeader("HTTP_X_FORWARDED_FOR");
			}
			if (ip == null || ip.length() == 0 || STATUS_UNKONOW.equalsIgnoreCase(ip)) {
				ip = request.getRemoteAddr();
			}
		} else if (ip.length() > IP_LENGTH) {
			String[] ips = ip.split(",");
			for (int index = 0; index < ips.length; index++) {
				String strIp = (String) ips[index];
				if (!(STATUS_UNKONOW.equalsIgnoreCase(strIp))) {
					ip = strIp;
					break;
				}
			}
		}
		return ip;
	}


}