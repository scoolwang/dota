package com.zzy.cms.core.util.random;
import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.annotation.JsonFormat;
import cn.hutool.core.lang.Snowflake;
import cn.hutool.core.net.NetUtil;
import cn.hutool.core.util.IdUtil;
import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author kaige
 *
 */
@Component
@Slf4j
public class SnowflakeIdWorker {

	/**
	 * 终端ID
	 */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Value("${cms.snowflakeIdWorker.workerId:0}")
    private long workerId = 0;

    /**
     * 数据中心ID
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING)
    @Value("${cms.snowflakeIdWorker.datacenterId:1}")
    private long datacenterId = 1;
    
    private Snowflake snowflake = IdUtil.createSnowflake(workerId, datacenterId);
    
    @PostConstruct
    public void init(){
    	if(0 == workerId) {
    		workerId = NetUtil.ipv4ToLong(NetUtil.getLocalhostStr());
    	}
        log.info("当前机器的workId:{}, datacenterId:{}", workerId, datacenterId);
    }
    
    public synchronized long snowflakeId(){
        return snowflake.nextId();
    }
    
    public synchronized long snowflakeId(long workerId,long datacenterId){
        Snowflake snowflake = IdUtil.createSnowflake(workerId, datacenterId);
        return snowflake.nextId();
    }
    
    

}

