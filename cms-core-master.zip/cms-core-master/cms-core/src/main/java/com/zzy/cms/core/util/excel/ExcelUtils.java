package com.zzy.cms.core.util.excel;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.VerticalAlignment;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

/**
 * 
 * @author guokaige
 *
 */
public class ExcelUtils {

	/**
	 * 文件的基础路径
	 */
	public static String FILE_BASH_PATH = System.getProperty("user.dir") + File.separator + "excel" + File.separator;

    public static final String OFFICE_EXCEL_XLS = "xls";
    public static final String OFFICE_EXCEL_XLSX = "xlsx";

    /**
             * 读取指定Sheet也的内容
     * @param filepath filepath 文件全路径
     * @param sheetNo sheet序号,从0开始,如果读取全文sheetNo设置null
     */
    public static String readExcel(String filepath, Integer sheetNo)
            throws EncryptedDocumentException, InvalidFormatException, IOException {
        StringBuilder sb = new StringBuilder();
        Workbook workbook = getWorkbook(filepath);
        if (workbook != null) {
            if (sheetNo == null) {
                int numberOfSheets = workbook.getNumberOfSheets();
                for (int i = 0; i < numberOfSheets; i++) {
                    Sheet sheet = workbook.getSheetAt(i);
                    if (sheet == null) {
                        continue;
                    }
                    sb.append(readExcelSheet(sheet));
                }
            } else {
                Sheet sheet = workbook.getSheetAt(sheetNo);
                if (sheet != null) {
                    sb.append(readExcelSheet(sheet));
                }
            }
        }
        return sb.toString();
    }

    /**
     * 根据文件路径获取Workbook对象
     * @param filepath 文件全路径
     */
    public static Workbook getWorkbook(String filepath)
            throws EncryptedDocumentException, InvalidFormatException, IOException {
        InputStream is = null;
        Workbook wb = null;
        if (StringUtils.isBlank(filepath)) {
            throw new IllegalArgumentException("文件路径不能为空");
        } else {
            String suffiex = getSuffiex(filepath);
            if (StringUtils.isBlank(suffiex)) {
                throw new IllegalArgumentException("文件后缀不能为空");
            }
            if (OFFICE_EXCEL_XLS.equals(suffiex) || OFFICE_EXCEL_XLSX.equals(suffiex)) {
                try {
                    is = new FileInputStream(filepath);
                    wb = WorkbookFactory.create(is);
                } finally {
                    if (is != null) {
                        is.close();
                    }
                    if (wb != null) {
                        wb.close();
                    }
                }
            } else {
                throw new IllegalArgumentException("该文件非Excel文件");
            }
        }
        return wb;
    }

    /**
                * 获取后缀
     * @param filepath filepath 文件全路径
     */
    private static String getSuffiex(String filepath) {
        if (StringUtils.isBlank(filepath)) {
            return "";
        }
        int index = filepath.lastIndexOf(".");
        if (index == -1) {
            return "";
        }
        return filepath.substring(index + 1, filepath.length());
    }

    private static String readExcelSheet(Sheet sheet) {
        StringBuilder sb = new StringBuilder();
        if(sheet != null){
        	// 得到excel的总记录条数
            int rowNos = sheet.getLastRowNum();
         // 遍历行
            for (int i = 0; i <= rowNos; i++) {
                Row row = sheet.getRow(i);
                if(row != null){
                	// 表头总共的列数
                    int columNos = row.getLastCellNum();
                    for (int j = 0; j < columNos; j++) {
                        Cell cell = row.getCell(j);
                        if(cell != null){
                            //cell.setCellType(CellType.STRING);
                            sb.append(cell.getStringCellValue() + " ");
                        }
                    }
                }
                sb.append(",");
            }
        }
        return sb.toString();
    }

    /**
             * 读取指定Sheet页的表头
     * @param filepath filepath 文件全路径
     * @param sheetNo sheet序号,从0开始,必填
     */
    public static Row readTitle(String filepath, int sheetNo)
            throws IOException, EncryptedDocumentException, InvalidFormatException {
        Row returnRow = null;
        Workbook workbook = getWorkbook(filepath);
        if (workbook != null) {
            Sheet sheet = workbook.getSheetAt(sheetNo);
            returnRow = readTitle(sheet);
        }
        return returnRow;
    }

    /**
     * 读取指定Sheet页的表头
     */
    private static Row readTitle(Sheet sheet) throws IOException {
        Row returnRow = null;
     // 得到excel的总记录条数
        int totalRow = sheet.getLastRowNum();
     // 遍历行
        for (int i = 0; i < totalRow; i++) {
            Row row = sheet.getRow(i);
            if (row == null) {
                continue;
            }
            returnRow = sheet.getRow(0);
            break;
        }
        return returnRow;
    }

    /**
             * 创建Excel文件
     * @param filepath filepath 文件全路径
     * @param sheetName 新Sheet页的名字
     * @param titles 表头
     * @param values 每行的单元格
     */
    public static boolean writeExcel(String filepath, String sheetName, List<String> titles,
            List<Map<String, Object>> values) throws IOException {
        if (StringUtils.isBlank(filepath)) {
            throw new IllegalArgumentException("文件路径不能为空");
        } else {
            String suffiex = getSuffiex(filepath);
            if (StringUtils.isBlank(suffiex)) {
                throw new IllegalArgumentException("文件后缀不能为空");
            }
            return writeToFile(filepath, sheetName, titles, values);
        }
    }
    
    private static boolean writeToFile(String filepath,String sheetName,List<String> titles,
            List<Map<String, Object>> values) throws IOException {
    	OutputStream outputStream = null;
    	String suffiex = getSuffiex(filepath);
        Workbook workbook;
        if (OFFICE_EXCEL_XLS.equals(suffiex.toLowerCase())) {
            workbook = new HSSFWorkbook();
        } else {
            workbook = new XSSFWorkbook();
        }
        // 生成一个表格
        Sheet sheet;
        if (StringUtils.isBlank(sheetName)) {
            // name 为空则使用默认值
            sheet = workbook.createSheet();
        } else {
            sheet = workbook.createSheet(sheetName);
        }
        // 设置表格默认列宽度为15个字节
        sheet.setDefaultColumnWidth((short) 15);
        // 生成样式
        Map<String, CellStyle> styles = createStyles(workbook);
        // 创建标题行
        Row row = sheet.createRow(0);
        // 存储标题在Excel文件中的序号
        Map<String, Integer> titleOrder = Maps.newHashMap();
        for (int i = 0; i < titles.size(); i++) {
            Cell cell = row.createCell(i);
            cell.setCellStyle(styles.get("header"));
            String title = titles.get(i);
            cell.setCellValue(title);
            titleOrder.put(title, i);
        }
        // 写入正文
        Iterator<Map<String, Object>> iterator = values.iterator();
        // 行号
        int index = 1;
        while (iterator.hasNext()) {
            row = sheet.createRow(index);
            Map<String, Object> value = iterator.next();
            for (Map.Entry<String, Object> map : value.entrySet()) {
                // 获取列名
                String title = map.getKey();
                // 根据列名获取序号
                int i = titleOrder.get(title);
                // 在指定序号处创建cell
                Cell cell = row.createCell(i);
                // 设置cell的样式
                if (index % 2 == 1) {
                    cell.setCellStyle(styles.get("cellA"));
                } else {
                    cell.setCellStyle(styles.get("cellB"));
                }
                // 获取列的值
                Object object = map.getValue();
                // 判断object的类型
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                if (object instanceof Double) {
                    cell.setCellValue((Double) object);
                } else if (object instanceof Date) {
                    String time = simpleDateFormat.format((Date) object);
                    cell.setCellValue(time);
                } else if (object instanceof Calendar) {
                    Calendar calendar = (Calendar) object;
                    String time = simpleDateFormat.format(calendar.getTime());
                    cell.setCellValue(time);
                } else if (object instanceof Boolean) {
                    cell.setCellValue((Boolean) object);
                } else {
                    if (object != null) {
                        cell.setCellValue(object.toString());
                    }
                }
            }
            index++;
        }

        return writeAndClose(outputStream, filepath, workbook);
    }
    
    /**
     * 关闭
     * @param outputStream
     * @param filepath
     * @param workbook
     * @return
     * @throws IOException
     */
    private static boolean writeAndClose(OutputStream outputStream, String filepath, Workbook workbook) throws IOException {

        try {
            outputStream = new FileOutputStream(filepath);
            workbook.write(outputStream);
            return true;
        } finally {
            if (outputStream != null) {
                outputStream.close();
            }
            if (workbook != null) {
                workbook.close();
            }
        }
    }
    
    /**
     * 创建Excel文件
     * @param sheetName 新Sheet页的名字
     * @param titles 表头
     * @param values 每行的单元格
     */
    public static byte[] writeExcel(String sheetName, List<String> titles,
            List<Map<String, Object>> values) throws IOException {
    	
    		ByteArrayOutputStream outputStream = new ByteArrayOutputStream();

            Workbook workbook = new XSSFWorkbook();
            // 生成一个表格
            Sheet sheet;
            if (StringUtils.isBlank(sheetName)) {
                // name 为空则使用默认值
                sheet = workbook.createSheet();
            } else {
                sheet = workbook.createSheet(sheetName);
            }
            // 设置表格默认列宽度为15个字节
            sheet.setDefaultColumnWidth((short) 15);
            // 生成样式
            Map<String, CellStyle> styles = createStyles(workbook);
            // 创建标题行
            Row row = sheet.createRow(0);
            // 存储标题在Excel文件中的序号
            Map<String, Integer> titleOrder = Maps.newHashMap();
            for (int i = 0; i < titles.size(); i++) {
                Cell cell = row.createCell(i);
                cell.setCellStyle(styles.get("header"));
                String title = titles.get(i);
                cell.setCellValue(title);
                titleOrder.put(title, i);
            }
            // 写入正文
            Iterator<Map<String, Object>> iterator = values.iterator();
            // 行号
            int index = 1;
            while (iterator.hasNext()) {
                row = sheet.createRow(index);
                Map<String, Object> value = iterator.next();
                for (Map.Entry<String, Object> map : value.entrySet()) {
                    // 获取列名
                    String title = map.getKey();
                    // 根据列名获取序号
                    int i = titleOrder.get(title);
                    // 在指定序号处创建cell
                    Cell cell = row.createCell(i);
                    // 设置cell的样式
                    if (index % 2 == 1) {
                        cell.setCellStyle(styles.get("cellA"));
                    } else {
                        cell.setCellStyle(styles.get("cellB"));
                    }
                    // 获取列的值
                    Object object = map.getValue();
                    // 判断object的类型
                    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    if (object instanceof Double) {
                        cell.setCellValue((Double) object);
                    } else if (object instanceof Date) {
                        String time = simpleDateFormat.format((Date) object);
                        cell.setCellValue(time);
                    } else if (object instanceof Calendar) {
                        Calendar calendar = (Calendar) object;
                        String time = simpleDateFormat.format(calendar.getTime());
                        cell.setCellValue(time);
                    } else if (object instanceof Boolean) {
                        cell.setCellValue((Boolean) object);
                    } else {
                        if (object != null) {
                            cell.setCellValue(object.toString());
                        }
                    }
                }
                index++;
            }
            return writeAndClose(outputStream, workbook);
    }
    
    /**
     * 关闭
     * @param outputStream
     * @param workbook
     * @return
     * @throws IOException
     */
    private static byte[] writeAndClose(ByteArrayOutputStream outputStream, Workbook workbook) throws IOException {

        try {
            workbook.write(outputStream);
            return outputStream.toByteArray();
        } finally {
            if (outputStream != null) {
                outputStream.close();
            }
            if (workbook != null) {
                workbook.close();
            }
        }
    }

    /**
     * 设置格式
     */
    private static Map<String, CellStyle> createStyles(Workbook wb) {
        Map<String, CellStyle> styles = Maps.newHashMap();

        // 标题样式
        XSSFCellStyle titleStyle =  (XSSFCellStyle) wb.createCellStyle();
        // 水平对齐
        titleStyle.setAlignment(HorizontalAlignment.CENTER); 
        // 垂直对齐
        titleStyle.setVerticalAlignment(VerticalAlignment.CENTER); 
        // 样式锁定
        titleStyle.setLocked(true); 
        titleStyle.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        Font titleFont = wb.createFont();
        titleFont.setFontHeightInPoints((short) 16);
        titleFont.setBold(true);
        titleFont.setFontName("微软雅黑");
        titleStyle.setFont(titleFont);
        styles.put("title", titleStyle);

        // 文件头样式
        XSSFCellStyle headerStyle = (XSSFCellStyle) wb.createCellStyle();
        headerStyle.setAlignment(HorizontalAlignment.CENTER);
        headerStyle.setVerticalAlignment(VerticalAlignment.CENTER);
        // 前景色
        headerStyle.setFillForegroundColor(IndexedColors.LIGHT_BLUE.getIndex()); 
        // 颜色填充方式
        headerStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND); 
        headerStyle.setWrapText(true);
        // 设置边界
        headerStyle.setBorderRight(BorderStyle.THIN); 
        headerStyle.setRightBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderLeft(BorderStyle.THIN);
        headerStyle.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderTop(BorderStyle.THIN);
        headerStyle.setTopBorderColor(IndexedColors.BLACK.getIndex());
        headerStyle.setBorderBottom(BorderStyle.THIN);
        headerStyle.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        Font headerFont = wb.createFont();
        headerFont.setFontHeightInPoints((short) 12);
        headerFont.setColor(IndexedColors.WHITE.getIndex());
        titleFont.setFontName("微软雅黑");
        headerStyle.setFont(headerFont);
        styles.put("header", headerStyle);
        
        //正文样式
        createContentBgStyle(wb, styles);
        
        return styles;
    }
    
    /**
     * 正文样式
     * @param wb
     * @param styles
     */
    private static void createContentBgStyle(Workbook wb, Map<String, CellStyle> styles) {

        Font cellStyleFont = wb.createFont();
        cellStyleFont.setFontHeightInPoints((short) 12);
        cellStyleFont.setColor(IndexedColors.BLUE_GREY.getIndex());
        cellStyleFont.setFontName("微软雅黑");

        // 正文样式A
        XSSFCellStyle cellStylea = (XSSFCellStyle) wb.createCellStyle();
        // 居中设置
        cellStylea.setAlignment(HorizontalAlignment.CENTER); 
        cellStylea.setVerticalAlignment(VerticalAlignment.CENTER);
        cellStylea.setWrapText(true);
        cellStylea.setBorderRight(BorderStyle.THIN);
        cellStylea.setRightBorderColor(IndexedColors.BLACK.getIndex());
        cellStylea.setBorderLeft(BorderStyle.THIN);
        cellStylea.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        cellStylea.setBorderTop(BorderStyle.THIN);
        cellStylea.setTopBorderColor(IndexedColors.BLACK.getIndex());
        cellStylea.setBorderBottom(BorderStyle.THIN);
        cellStylea.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        cellStylea.setFont(cellStyleFont);
        styles.put("cellA", cellStylea);
        
        // 正文样式B:添加前景色为浅黄色
        XSSFCellStyle cellStyleb = (XSSFCellStyle) wb.createCellStyle();
        cellStyleb.setAlignment(HorizontalAlignment.CENTER);
        cellStyleb.setVerticalAlignment(VerticalAlignment.CENTER);
        cellStyleb.setFillForegroundColor(IndexedColors.LIGHT_YELLOW.getIndex());
        cellStyleb.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        cellStyleb.setWrapText(true);
        cellStyleb.setBorderRight(BorderStyle.THIN);
        cellStyleb.setRightBorderColor(IndexedColors.BLACK.getIndex());
        cellStyleb.setBorderLeft(BorderStyle.THIN);
        cellStyleb.setLeftBorderColor(IndexedColors.BLACK.getIndex());
        cellStyleb.setBorderTop(BorderStyle.THIN);
        cellStyleb.setTopBorderColor(IndexedColors.BLACK.getIndex());
        cellStyleb.setBorderBottom(BorderStyle.THIN);
        cellStyleb.setBottomBorderColor(IndexedColors.BLACK.getIndex());
        cellStyleb.setFont(cellStyleFont);
        styles.put("cellB", cellStyleb);
    }
    

    /**
     * 将源文件的内容复制到新Excel文件(可供理解Excel使用,使用价值不大)
     * @param srcFilepath 源文件全路径
     * @param desFilepath 目标文件全路径
     */
    public static void writeExcel(String srcFilepath, String desFilepath)
            throws IOException, EncryptedDocumentException, InvalidFormatException {
        FileOutputStream outputStream = null;
        String suffiex = getSuffiex(desFilepath);
        if (StringUtils.isBlank(suffiex)) {
            throw new IllegalArgumentException("文件后缀不能为空");
        }
        Workbook workbookDes;
        if (OFFICE_EXCEL_XLS.equals(suffiex.toLowerCase())) {
            workbookDes = new HSSFWorkbook();
        } else {
            workbookDes = new XSSFWorkbook();
        }
        Workbook workbook = getWorkbook(srcFilepath);
        if (workbook != null) {
            int numberOfSheets = workbook.getNumberOfSheets();
            for (int k = 0; k < numberOfSheets; k++) {
                Sheet sheet = workbook.getSheetAt(k);
                Sheet sheetDes = workbookDes.createSheet(sheet.getSheetName());
                if (sheet != null) {
                    int rowNos = sheet.getLastRowNum();
                    for (int i = 0; i <= rowNos; i++) {
                        Row row = sheet.getRow(i);
                        Row rowDes = sheetDes.createRow(i);
                        if(row != null){
                            int columNos = row.getLastCellNum();
                            for (int j = 0; j < columNos; j++) {
                                Cell cell = row.getCell(j);
                                Cell cellDes = rowDes.createCell(j);
                                if(cell != null){
                                    cell.setCellType(CellType.STRING);
                                    cellDes.setCellType(CellType.STRING);
                                    cellDes.setCellValue(cell.getStringCellValue());
                                }
                            }
                        }
                    }
                }
                
            }
        }
        writeAndClose(outputStream, workbookDes, workbook, srcFilepath, desFilepath);
    }
    
    /**
     * 关闭
     * @param outputStream
     * @param workbookDes
     * @param workbook
     * @param srcFilepath
     * @param desFilepath
     * @throws IOException
     */
    private static void writeAndClose(FileOutputStream outputStream, Workbook workbookDes,Workbook workbook, String srcFilepath, String desFilepath) throws IOException {
        try {
            outputStream = new FileOutputStream(desFilepath);
            workbookDes.write(outputStream);
        } finally {
            if (outputStream != null) {
                outputStream.close();
            }
            if (workbookDes != null) {
                workbookDes.close();
            }
            if (workbookDes != null) {
                workbookDes.close();
            }
        }
    }
    
    
    
    public static void main(String[] args) throws IOException, EncryptedDocumentException, InvalidFormatException {
//    	List<String> titles = Lists.newArrayList("id","name");
//        List<Map<String, Object>> values = Lists.newArrayList();
//        
//        Map<String, Object> map = Maps.newHashMap();
//        map.put("id", "123");
//        map.put("name", "你好");
//        values.add(map);
//        
//    	ExcelUtils.writeExcel("D://java/a.xlsx", "企业邮寄列表", titles, values);
    	
    	
    	String str = ExcelUtils.readExcel("D://java/123.xlsx", 0);
    	System.out.println(str);
    	
    }
}