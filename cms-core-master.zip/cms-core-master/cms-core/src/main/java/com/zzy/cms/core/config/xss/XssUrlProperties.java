package com.zzy.cms.core.config.xss;

import java.util.ArrayList;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;

import lombok.Data;

/**
 * Xss配置类
 *
 * @author Chill
 */
@Data
@ConfigurationProperties("topnet.xss.url")
public class XssUrlProperties {

	private final List<String> excludePatterns = new ArrayList<>();

}
