package com.zzy.cms.core.config;

import java.net.InetAddress;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

import com.zzy.cms.core.util.string.StringsUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 
 * @author kaige
 *
 */
@Component("coreCmsApplicationRunner")
@Slf4j
public class CmsApplicationRunner implements ApplicationRunner {
	
	private String host = "localhost";
	
	@Value("${server.port:8080}")
	private String port;
	
	@Value("${server.httpPort:10005}")
	private String httpPort;
	
	@Value("${server.servlet.context-path:}")
	private String contextPath;

    @Override
    public void run(ApplicationArguments  var1) throws Exception{
    	
    	InetAddress addr = InetAddress.getLocalHost();
	    String hostAddr = addr.getHostAddress();
	    if(StringsUtils.hasText(hostAddr)) {
		    host = hostAddr;
	    }
		log.info("---------启动成功,访问首页: http://{}:{}{}/","localhost",httpPort,contextPath);
		log.info("---------启动成功,访问druid: http://{}:{}{}/druid",host,httpPort,contextPath);
		log.info("---------启动成功,访问knife4j: http://{}:{}{}/doc.html",host,httpPort,contextPath);
    }
}