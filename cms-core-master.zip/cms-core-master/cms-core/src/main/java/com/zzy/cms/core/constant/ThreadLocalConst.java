package com.zzy.cms.core.constant;


/**
 *
 * @author kaige
 *
 */
public class ThreadLocalConst {
	
	/**
	 * 存储HttpServletRequest
	 */
    public static final String HTTP_REQUEST_KEY = "http_request_key";
    
	/**
	 * 用户Id
	 */
	public static final String CMS_USER_ID_KEY = "CMS_USER_ID_KEY";
	
	
	/**
	 * 用户
	 */
	public static final String CMS_USER_KEY = "CMS_USER_KEY";

}
