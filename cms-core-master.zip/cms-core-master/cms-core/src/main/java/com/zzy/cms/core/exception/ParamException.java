package com.zzy.cms.core.exception;

import java.util.Map;

import com.google.common.collect.Maps;
import com.zzy.cms.core.util.json.FastJsonUtil;

/**
 *
 * @author guokaige
 *
 */
public class ParamException extends RuntimeException{


	private static final long serialVersionUID = 1L;


	private String message;

	private String errorField;

	private Map<String,String> errorFieldMap;


	@Override
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getErrorField() {
		return errorField;
	}

	public void setErrorField(String errorField) {
		this.errorField = errorField;
	}

	public Map<String, String> getErrorFieldMap() {
		return errorFieldMap;
	}

	public void setErrorFieldMap(Map<String, String> errorFieldMap) {
		this.errorFieldMap = errorFieldMap;
	}

	public ParamException(String message, String errorField) {
		super();
		this.message = message;
		this.errorField = errorField;
		this.errorFieldMap =Maps.newHashMap();
		this.errorFieldMap.put(errorField, message);
	}

	public ParamException(Map<String, String> errorFieldMap) {
		super();
		this.errorFieldMap = errorFieldMap;
	}

	@Override
	public String toString() {
		return FastJsonUtil.fastJsonSerialize(errorFieldMap);
	}








}
