package com.zzy.cms.core.util.json;

import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.util.ParameterizedTypeImpl;
import com.zzy.cms.core.dto.Result;

/**
 *
 * @author guokaige
 *
 */
public class FastJsonUtil {

	/**
	 * 转换json字符串 JSON也是一种序列化。
	 *
	 * @param object
	 * @return
	 */
	public static String fastJsonSerialize(Object object) {
		return JSON.toJSONString(object, SerializerFeature.DisableCircularReferenceDetect);
	}

	/**
	 * 字符串转对象
	 *
	 * @param object
	 * @param clazz
	 * @return
	 */
	public static <T> T unFastJsonSerialize(String object, Class<T> clazz) {
		T t = null;
		try {
			t = JSON.parseObject(object, clazz);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return t;
	}
	
	public static <T> Result<T> parseResult(String json, Class<T> clazz) {
	    return JSONObject.parseObject(json, new TypeReference<Result<T>>(clazz) {});
	}
	
	public static <T> Result<List<T>> parseListResult(String json, Class<T> clazz) {
		Result<List<T>> result = Result.error("json解析异常");
		try {
			result = JSONObject.parseObject(json, buildType(Result.class, List.class, clazz));
		} catch (Exception e) {
			e.printStackTrace();
		}
	    return result;
	}

	private static Type buildType(Type... types) {
	    ParameterizedTypeImpl beforeType = null;
	    if (types != null && types.length > 0) {
	        for (int i = types.length - 1; i > 0; i--) {
	            beforeType = new ParameterizedTypeImpl(new Type[]{beforeType == null ? types[i] : beforeType}, null, types[i - 1]);
	        }
	    }
	    return beforeType;
	}
	

	public static <T> Map<String, T> json2Map(String jsonStr) {
		Map<String, T > params = JSONObject.parseObject(jsonStr, new TypeReference<Map<String, T>>(){});
		return params;
	}

    public static <T> List<T> json2List(String jsonStr, Class<T> classOft) {
		return JSON.parseArray(jsonStr, classOft);
    }

    
    /**
     * json 美化
     * @param json
     * @return
     */
    public static String prettyJson(String json){
        if(StringUtils.isBlank(json)){
            return json;
        }
        JSONObject jsonObject = null;
        try {
            jsonObject = JSONObject.parseObject(json);
        }catch (Exception e){
            return json;
        }
        return JSONObject.toJSONString(jsonObject,true);
    }



    public static void main(String[] args) {

		String jsonStr="{'code':'22','ip':'aa','address':'ss'}";
		Map<String ,Object> map2=FastJsonUtil.json2Map(jsonStr);
		System.out.println(map2.size());

	}











}
