package com.zzy.cms.core.base.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.hibernate.type.Type;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.repository.NoRepositoryBean;

import com.zzy.cms.core.base.jpa.plus.QueryWrapper;

/**
 *
 * @author guokaige
 * @Date   2019年3月27日 上午8:37:36
 * @param <T>
 * @param <ID>
 */
@NoRepositoryBean
public interface BaseDao<T, ID extends Serializable> extends JpaRepository<T,ID>, JpaSpecificationExecutor<T> {


	/**
	 *
	 * @Title:       保存
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param entity
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:09:16
	 */
	@Override
	<S extends T> S save(S entity);
	
	
	/**
	 * 带Id保存
	 * @param <S>
	 * @param entity
	 * @return
	 */
	<S extends T> S saveWithId(S entity);
	
	
	/**
	 * 更新
	 * @param id
	 * @param entity
	 * @return
	 */
	<S extends T> S update(ID id, S entity);
	
	
	
	/**
	 * 有id就更新, 没id就保存
	 * @param <S>
	 * @param entity
	 * @return
	 */
	<S extends T> S saveOrUpdate(S entity);

	
	
	/**
	 *
	 * @Title:      通过ID获取
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:09:16
	 */
	@Override
	Optional<T> findById(ID id) ;
	
	
	/**
	 * 查询state01
	 * @param id
	 * @return
	 */
	Optional<T> findEnableById(ID id) ;
	
	
	/**
	 *
	 * @Title:        通过主键获取
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param id
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:09:16
	 */
	T getById(ID id);
	
	
	/**
	 * 按属性查找对象列表, 匹配方式为相等.
	 * @param propertyName
	 * @param value
	 * @return
	 */
	List<T> findBy(final String propertyName, final Object value);
	

	/**
	 * 按属性查找唯一对象, 匹配方式为相等.
	 * @param propertyName
	 * @param value
	 * @return
	 */
	T findUniqueBy(final String propertyName, final Object value);
	
	
    /**
     * 获取单条结果
     * @param <X>
     * @param sql
     * @param params
     * @return
     */
    <X> X findUniqueWithSql(String sql, Map<String, Object> params);


	/**
	 *
	 * @Title:      通过ID批量获取
	 * @param ids
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:09:16
	 */
	List<T> findByIds(Iterable<ID> ids);


	/**
	 *
	 * @Title:        批量保存
	 * @param beans    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午9:09:43
	 */
	void batchSave(List<T> beans);
	
	
	/**
	 * 批量删除
	 * @param ids
	 */
	void batchDelete(Iterable<ID> ids);

    /**
    *
    * @Title:        这个用于执行删除和更新的hql语句
    * @Description:  TODO(这里用一句话描述这个方法的作用)
    * @param hql
    * @param params
    * @return    
    * @author        guokaige
    * @Date          2019年4月2日 上午10:39:26
    
    */
   int executeHql(String hql, Map<String, Object> params);



	/**
	 *
	 * @Title:        执行删除和更新的sql语句
	 * @Description:  TODO(这里用一句话描述这个方法的作用)
	 * @param sql
	 * @param params
	 * @return    
	 * @author        guokaige
	 * @Date          2019年4月2日 上午10:39:12
	 */
    int executeSql(String sql, Map<String, Object> params);
    
    
    
	/**
	 * jpa list查询
	 * @param sql
	 * @param params
	 * @return
	 */
	List<Map<String,Object>> findSql(String sql, Map<String, Object> params);


	/**
	 *  分页查询map
	 * @param pageable
	 * @param sql
	 * @param params
	 * @return
	 */
	Page<Map<String, Object>> findPageSql(Pageable pageable, String sql, Map<String, Object> params);
    

	/**
	 * jpa list查询 ,  自动类型转换器BeanTransformerAdapter转换,   如果自动转换失败,请选择下面自定义类型转换
	 * @param <T1>
	 * @param sql
	 * @param clazz
	 * @param params
	 * @return
	 */
	<T1> List<T1> findSql(String sql, Class<T1> clazz, Map<String, Object> params);
	
	
    /**
     * jpa list查询, 自定义类型转换
     * @param <T1>
     * @param sql
     * @param clazz
     * @param params
     * @param attrTypes  自定义类型转换Map
     * @return
     */
	<T1> List<T1> findSql(String sql, Class<T1> clazz, Map<String, Object> params, Map<String, Type> attrTypes);
	
	

	
    /**
     * sql分页查询  自动类型转换器BeanTransformerAdapter转换
     * @param <T2>
     * @param sql
     * @param clazz
     * @param pageable
     * @param params
     * @return
     */
    <T2> Page<T2> findPageSql(String sql,Class<T2> clazz,Pageable pageable, Map<String, Object> params);


    
     /**
      * sql分页查询 自定义类型转换  
      * @param <T2>
      * @param sql
      * @param clazz
      * @param pageable
      * @param params
      * @param attrTypes  自定义类型转换Map
      * @return
      */
    <T2> Page<T2> findPageSql(String sql,Class<T2> clazz,Pageable pageable, Map<String, Object> params, Map<String, Type> attrTypes);

	
    
    /**
     * jpa Hql查询
     * @param <T2>
     * @param hql
     * @param clazz
     * @param params
     * @return
     */
    <T2> List<T2> findHql(String hql, Class<T2> clazz, Map<String, Object> params);
    
    
    /**
     * jpa Hql分页查询
     * @param <T2>
     * @param hql
     * @param clazz
     * @param pageable
     * @param params
     * @return
     */
    <T2> Page<T2> findPageHql(String hql,Class<T2> clazz,Pageable pageable, Map<String, Object> params);
    
    
    
    /**
     * 通过wapper查询
     * @param queryWrapper
     * @return
     */
    List<T> findByQueryWrapper(QueryWrapper queryWrapper);
    
    
    /**
     * 通过wapper查询
     * @param queryWrapper
     * @param sort
     * @return
     */
    List<T> findSortByQueryWrapper(QueryWrapper queryWrapper, Sort sort);
    
    
    /**
     * 通过wapper分页查询
     * @param queryWrapper
     * @param pageable
     * @return
     */
    Page<T> findPageByQueryWrapper(QueryWrapper queryWrapper, Pageable pageable);

    
    
    /**
     * 获取 EntityManager
     * @return
     */
    public EntityManager getEntityManager();

}
