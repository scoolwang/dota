package com.zzy.cms.core.constant;


/**
 * 
 * @author guokaige
 *
 */
public class CharsetConst {
	
	 public static final String UTF8 = "UTF-8";
	 public static final String GBK = "GBK";
	 public static final String GB2312 = "GB2312";
	 public static final String ISO88591 = "ISO-8859-1";

}
