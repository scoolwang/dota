package com.zzy.cms.core.util.vaildatecode.processor;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.request.ServletWebRequest;

import com.zzy.cms.core.constant.SessionConst;
import com.zzy.cms.core.util.vaildatecode.ImageCode;
import com.zzy.cms.core.util.vaildatecode.ValidateCode;
import com.zzy.cms.core.util.vaildatecode.generator.ValidateCodeGenerator;

import net.sf.jmimemagic.Magic;
import net.sf.jmimemagic.MagicMatch;

/**
 * 
 * @author guokaige
 * @date: 2018年10月11日 下午2:46:36
 */
public class ImageCodeProcessor extends BaseDefaultValidateCodeProcessor {

	private Logger logger = LoggerFactory.getLogger(getClass());

	protected ValidateCodeGenerator imageCodeGenerator;

	@Override
	public ValidateCode generateCode(ServletWebRequest request) {
		ImageCode imageCode = (ImageCode) imageCodeGenerator.generate(request.getRequest());
		logger.info("生成图片验证码{}", imageCode.getCode());
		request.getRequest().getSession().setAttribute(SessionConst.SESSION_VALIDATE_CODE_IMAGE_KEY, imageCode);
		return imageCode;
	}

	@Override
	public void send(ServletWebRequest request, ValidateCode validateCode) throws IOException {

        if(validateCode instanceof ImageCode) {
			BufferedImage bufferedImage = ((ImageCode) validateCode).getImage();
			ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
			ImageIO.write(bufferedImage, "PNG", byteArrayOutputStream);

			try {
				byte[] data = byteArrayOutputStream.toByteArray();
				MagicMatch match = Magic.getMagicMatch(data);
				String mimeType = match.getMimeType();
				HttpServletResponse response = request.getResponse();

				// 设置响应的类型格式为图片格式
				response.setContentType(mimeType);
				// 禁止图像缓存。
				response.setHeader("Pragma", "no-cache");
				response.setHeader("Cache-Control", "no-cache");
				response.setDateHeader("Expires", 0);
				BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
				bos.write(data);
				byteArrayOutputStream.close();
				bos.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	public ValidateCodeGenerator getImageCodeGenerator() {
		return imageCodeGenerator;
	}

	public void setImageCodeGenerator(ValidateCodeGenerator imageCodeGenerator) {
		this.imageCodeGenerator = imageCodeGenerator;
	}

	public ImageCodeProcessor(ValidateCodeGenerator imageCodeGenerator) {
		super();
		this.imageCodeGenerator = imageCodeGenerator;
	}
	
	

}
