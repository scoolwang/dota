package com.zzy.cms.core.base.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.ParameterExpression;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.query.internal.NativeQueryImpl;
import org.hibernate.transform.Transformers;
import org.hibernate.type.Type;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.JpaEntityInformationSupport;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.data.repository.NoRepositoryBean;
import org.springframework.lang.Nullable;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import com.zzy.cms.core.base.jpa.JpaQuery;
import com.zzy.cms.core.base.jpa.plus.QueryWrapper;
import com.zzy.cms.core.base.jpa.plus.SpecificationUtils;
import com.zzy.cms.core.base.model.BaseModelEntity;
import com.zzy.cms.core.base.model.BaseModelUUIDEntity;
import com.zzy.cms.core.constant.PropertyConst;
import com.zzy.cms.core.constant.StateConst;
import com.zzy.cms.core.constant.ThreadLocalConst;
import com.zzy.cms.core.util.OperationUtil;
import com.zzy.cms.core.util.ThreadLocalUtil;
import com.zzy.cms.core.util.bean.BeanUtil;
import com.zzy.cms.core.util.bean.ReflectUtils;

import lombok.extern.slf4j.Slf4j;

/**
 *
 * @author guokaige
 * @Date 2019年3月27日 上午8:37:31
 * @param <T>
 * @param <ID>
 */
@SuppressWarnings({ "unchecked", "rawtypes" })
@NoRepositoryBean
@Slf4j
public class BaseDaoImpl<T, ID extends Serializable> extends SimpleJpaRepository<T, ID> implements BaseDao<T, ID> {

	private static final String ID_MUST_NOT_BE_NULL = "The given id must not be null!";

	private EntityManager entityManager;

	private final Class<T> domainClass;

	private final JpaEntityInformation<T, ?> entityInformation;

	protected Logger logger = LoggerFactory.getLogger(getClass());

	public BaseDaoImpl(Class<T> domainClass, EntityManager entityManager) {
		super(domainClass, entityManager);
		this.entityManager = entityManager;
		this.domainClass = domainClass;
		this.entityInformation = JpaEntityInformationSupport.getEntityInformation(domainClass, entityManager);
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public <S extends T> S save(S entity) {
		if (!entityInformation.isNew(entity)) {
			log.warn("save with custom id !");
		}
		this.writeCreateOperation(entity);
		entityManager.persist(entity);
		return entity;
	}
	
	
	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public <S extends T> S saveWithId(S entity) {
		if (!entityInformation.isNew(entity)) {
			log.warn("save with custom id ! {}", entity);
		}
		this.writeCreateOperation(entity);
		S db = (S) entityManager.merge(entity);
		this.flush();
		return db;
	}
	
	
	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public <S extends T> S update(ID id, S entity) {
		Assert.notNull(id, "The given id must not be null !");
		T target = this.findById(id).orElse(null);
		Assert.notNull(target, "The given id invalid !");
		BeanUtil.copyProperties(entity,target);
		this.writeUpdateOperation(target);
		S db = (S) entityManager.merge(target);
		this.flush();
		return db;
	}
	
	
	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public <S extends T> S saveOrUpdate(S entity) {
		if (!entityInformation.isNew(entity)) {
			ID id = (ID) entityInformation.getId(entity);
			T target = this.findById(id).orElse(null);
			if(null!=target) {
				this.update(id, entity);
			}else {
				this.saveWithId(entity);
			}
		}else{
			this.save(entity);
		}
		return entity;
	}
	
	
	private void writeCreateOperation(Object entity) {
		String userId = this.getThreadLocalUserId();
		if(entity instanceof BaseModelUUIDEntity || entity instanceof BaseModelEntity ) {
			OperationUtil.writeCreateOperation(entity, userId);
		}
	}
	
	private <S extends T> void writeUpdateOperation(S entity) {
		String userId = this.getThreadLocalUserId();
		if(entity instanceof BaseModelUUIDEntity || entity instanceof BaseModelEntity ) {
			OperationUtil.writeUpdateOperation(entity, userId);
		}
	}
	
	private String getThreadLocalUserId() {
		String userId = null;
		Object obj = ThreadLocalUtil.getThreadMap().get(ThreadLocalConst.CMS_USER_ID_KEY);
		if(null != obj) {
			userId = (String) obj;
		}
		return userId;
	}
	

	/**
	 * 批量插入
	 * 
	 * @param beans
	 */
	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public void batchSave(List<T> beans) {
		int count = 0;
		if (beans != null) {
			for (T bean : beans) {
				count++;
				this.writeCreateOperation(bean);
				entityManager.persist(bean);
				if (count % 1000 == 0) {
					entityManager.flush();
					entityManager.clear();
				}
			}
			entityManager.flush();
			entityManager.clear();
		}

	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public int executeSql(String sql, Map<String, Object> params) {
		Query query = entityManager.createNativeQuery(sql);
		this.setParams(params, query);
		entityManager.close();
		Object obj = query.executeUpdate();
		return Integer.parseInt(obj.toString());
	}

	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public int executeHql(String hql, Map<String, Object> params) {
		Query query = entityManager.createQuery(hql);
		this.setParams(params, query);
		entityManager.close();
		Object obj = query.executeUpdate();
		return Integer.parseInt(obj.toString());
	}
	
	@Override
	@Transactional(rollbackFor = Exception.class, propagation = Propagation.REQUIRED, readOnly = false)
	public void batchDelete(Iterable<ID> ids) {
		Assert.notNull(ids, ID_MUST_NOT_BE_NULL);
		for (ID id : ids) {
			this.deleteById(id);
		}
	}
	
	@Override
	public Optional<T> findById(ID id) {
		Assert.notNull(id, ID_MUST_NOT_BE_NULL);
		return Optional.ofNullable(entityManager.find(domainClass, id));
	}
	
	@Override
	public T getById(ID id) {
		return entityManager.find(this.getDomainClass(), id);
	}
	

	@Override
	public List<T> findByIds(Iterable<ID> ids) {
		Assert.notNull(ids, "The given Iterable of Id's must not be null!");
		if (!ids.iterator().hasNext()) {
			return Collections.emptyList();
		}
		if (entityInformation.hasCompositeId()) {
			List<T> results = new ArrayList<T>();
			for (ID id : ids) {
				findById(id).ifPresent(results::add);
			}
			return results;
		}
		ByIdsSpecification<T> specification = new ByIdsSpecification<T>(entityInformation);
		TypedQuery<T> query = getQuery(specification, Sort.unsorted());
		return query.setParameter(specification.parameter, ids).getResultList();
	}

	@Override
	public <T1> List<T1> findSql(String sql, Class<T1> clazz, Map<String, Object> params) {
		Query query = null;
		if (ReflectUtils.isSimpleType(clazz)) {
			query = entityManager.createNativeQuery(sql);
		} else {
			Session session = entityManager.unwrap(Session.class);
			query = session.createNativeQuery(sql);
			query.unwrap(NativeQueryImpl.class).setResultTransformer(new BeanTransformerAdapter(clazz));
		}
		this.setParams(params, query);
		entityManager.close();
		return query.getResultList();
	}


	@Override
	public <T2> Page<T2> findPageSql(String sql, Class<T2> clazz, Pageable pageable, Map<String, Object> params) {
		Long totalCount = getSqlCount(sql, params);
		Query query = null;
		if (ReflectUtils.isSimpleType(clazz)) {
			query = entityManager.createNativeQuery(sql);
		} else {
			Session session = entityManager.unwrap(Session.class);
			query = session.createNativeQuery(sql);
			query.unwrap(NativeQueryImpl.class).setResultTransformer(new BeanTransformerAdapter(clazz));
		}
		this.setParams(params, query);
		this.limitDatas(pageable, query);
		entityManager.close();
		List<T2> data = query.getResultList();
		Page<T2> pageBean = new PageImpl(data, pageable, totalCount);
		return pageBean;
	}

	@Override
	public <T2> List<T2> findHql(String hql, Class<T2> clazz, Map<String, Object> params) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createQuery(hql);
		this.setParams(params, query);
		entityManager.close();
		return query.getResultList();
	}

	@Override
	public <T2> Page<T2> findPageHql(String hql, Class<T2> clazz, Pageable pageable, Map<String, Object> params) {
		Long totalCount = getHqlCount(hql, params);
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createQuery(hql);
		this.setParams(params, query);
		this.limitDatas(pageable, query);
		entityManager.close();
		List<T2> data = query.getResultList();
		Page<T2> pageBean = new PageImpl(data, pageable, totalCount);
		return pageBean;
	}

	
	
	/**
	 * 设置参数
	 * @param params
	 * @param query
	 */
	private void setParams(Map<String, Object> params, Query query) {
		if (null != params) {
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				String key = entry.getKey();
				Object value = entry.getValue();
				query.setParameter(key, value);
			}
		}
	}
	
	

	/**
	 * 数据分页
	 * @param pageable
	 * @param query
	 */
	private void limitDatas(Pageable pageable, Query query) {
    	Integer pageNum = pageable.getPageNumber();
    	Integer pageSize = pageable.getPageSize();
        if(pageNum != null && pageSize != null){
        	
            if(pageNum < 0) {
            	throw new RuntimeException("pageNum 不能小于0 ");
            }
           // 这里不再减一 是因为JPA的Pageable的页码从0开始 , 所以pageNum不再减1
            query.setFirstResult(pageNum * pageSize);
            query.setMaxResults(pageSize);
        }
    }
	
	private static final class ByIdsSpecification<T> implements Specification<T> {
		private static final long serialVersionUID = 1L;

		private final JpaEntityInformation<T, ?> entityInformation;

		@Nullable
		ParameterExpression<Iterable> parameter;

		ByIdsSpecification(JpaEntityInformation<T, ?> entityInformation) {
			this.entityInformation = entityInformation;
		}

		@Override
		public Predicate toPredicate(Root<T> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
			Path<?> path = root.get(entityInformation.getIdAttribute());
			parameter = cb.parameter(Iterable.class);
			return path.in(parameter);
		}
	}
	
	private Long getSqlCount(String sql, Map<String, Object> params) {
		int end = sql.toUpperCase().lastIndexOf("ORDER BY");
		String tempSql = sql;
		if (end > 0) {
			tempSql = tempSql.substring(0, end);
		}
		tempSql = "select count(1) from (" + tempSql + ") temp";
		Query query = entityManager.createNativeQuery(tempSql);
		this.setParams(params, query);
		return Long.parseLong(query.getSingleResult().toString());
	}

	private Long getHqlCount(String hql, Map<String, Object> params) {
		// 执行count操作
		boolean flag = hql.toUpperCase().startsWith("SELECT");
		int end = hql.toUpperCase().lastIndexOf("ORDER BY");
		
		String tempHql = hql;
		if (flag) {
			if (end > 0) {
				tempHql = tempHql.substring(0, end);
			}
			// 找到第一from
			int index = tempHql.toUpperCase().indexOf("FROM");
			tempHql = tempHql.substring(index);
			tempHql = "select count(1) " + tempHql;
		} else {
			tempHql = "select count(1) " + tempHql;
		}
		Query query = entityManager.createQuery(tempHql);
		this.setParams(params, query);
		return Long.parseLong(query.getSingleResult().toString());
	}

	
	
	@Override
	public List<Map<String, Object>> findSql(String sql, Map<String, Object> params) {
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createNativeQuery(sql);
		NativeQueryImpl nativeQuery = query.unwrap(NativeQueryImpl.class);
		nativeQuery.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		this.setParams(params, query);
		entityManager.close();
		return nativeQuery.getResultList();
	}


	
	@Override
	public <X> X findUniqueWithSql(final String sql, final Map<String, Object> params) {
		Assert.hasText(sql, "sql不能为空");
		Query query = entityManager.createNativeQuery(sql); 
		this.setParams(params, query);
		return (X) query.getSingleResult();
	}

	@Override
	public <T1> List<T1> findSql(String sql, Class<T1> clazz, Map<String, Object> params, Map<String, Type> attrTypes) {
		Query query = null;
		if (ReflectUtils.isSimpleType(clazz)) {
			query = entityManager.createNativeQuery(sql);
		} else {
			Session session = entityManager.unwrap(Session.class);
			query = session.createNativeQuery(sql);
			NativeQueryImpl nativeQuery = query.unwrap(NativeQueryImpl.class);
			if (null != attrTypes && !attrTypes.isEmpty()) {
				for (Map.Entry<String, Type> entry : attrTypes.entrySet()) {
					nativeQuery.addScalar(entry.getKey(), entry.getValue());
				}
			}
			nativeQuery.setResultTransformer(Transformers.aliasToBean(clazz));
		}
		this.setParams(params, query);
		entityManager.close();
		return query.getResultList();
	}

	@Override
	public <T2> Page<T2> findPageSql(String sql, Class<T2> clazz, Pageable pageable, Map<String, Object> params, Map<String, Type> attrTypes) {
		Long totalCount = getSqlCount(sql, params);
		Query query = null;
		if (ReflectUtils.isSimpleType(clazz)) {
			query = entityManager.createNativeQuery(sql);
		} else {
			Session session = entityManager.unwrap(Session.class);
			query = session.createNativeQuery(sql);
			NativeQueryImpl nativeQuery = query.unwrap(NativeQueryImpl.class);
			if (null != attrTypes && !attrTypes.isEmpty()) {
				for (Map.Entry<String, Type> entry : attrTypes.entrySet()) {
					nativeQuery.addScalar(entry.getKey(), entry.getValue());
				}
			}
			nativeQuery.setResultTransformer(Transformers.aliasToBean(clazz));
		}
		this.setParams(params, query);
		this.limitDatas(pageable, query);
		entityManager.close();
		List<T2> data = query.getResultList();
		Page<T2> pageBean = new PageImpl(data, pageable, totalCount);
		return pageBean;
	}
	
	
	
	

	@Override
	public Page<Map<String, Object>> findPageSql(Pageable pageable, String sql, Map<String, Object> params) {
		Long totalCount = getSqlCount(sql, params);
		Session session = entityManager.unwrap(Session.class);
		Query query = session.createNativeQuery(sql);
		NativeQueryImpl nativeQuery = query.unwrap(NativeQueryImpl.class);
		nativeQuery.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
		this.setParams(params, query);
		this.limitDatas(pageable, query);
		entityManager.close();
		List<Map<String, Object>> content = query.getResultList();
		Page<Map<String, Object>> pageBean = new PageImpl(content, pageable, totalCount);
		return pageBean;
	}
	

	@Override
	public List<T> findBy(String propertyName, Object value) {
		JpaQuery query = JpaQuery.forClass(this.getDomainClass(),entityManager);
		query.eq(propertyName, value);
		return entityManager.createQuery(query.newCriteriaQuery()).getResultList();
	}

	@Override
	public T findUniqueBy(String propertyName, Object value) {
		JpaQuery query = JpaQuery.forClass(this.getDomainClass(),entityManager);
		query.eq(propertyName, value);
		return (T)entityManager.createQuery(query.newCriteriaQuery()).getSingleResult();
	}

	@Override
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	@Override
	public List<T> findByQueryWrapper(QueryWrapper queryWrapper) {
		Specification<T> predicates = new SpecificationUtils<T>(domainClass).toPredicate(queryWrapper.getWhereList());
		List<T> list = this.findAll(predicates);
		return list;
	}
	
	@Override
	public List<T> findSortByQueryWrapper(QueryWrapper queryWrapper, Sort sort) {
		Specification<T> predicates = new SpecificationUtils<T>(domainClass).toPredicate(queryWrapper.getWhereList());
		List<T> list = this.findAll(predicates, sort);
		return list;
	}

	@Override
	public Page<T> findPageByQueryWrapper(QueryWrapper queryWrapper, Pageable pageable) {
		Specification<T> predicates = new SpecificationUtils<T>(domainClass).toPredicate(queryWrapper.getWhereList());
		Page<T> page = this.findAll(predicates, pageable);
		return page;
	}

	@Override
	public Optional<T> findEnableById(ID id) {
		JpaQuery query = JpaQuery.forClass(this.getDomainClass(),entityManager);
		query.eq(PropertyConst.ID, id);
		query.eq(PropertyConst.STATE, StateConst.ENABLE);
		T t = (T)entityManager.createQuery(query.newCriteriaQuery()).getSingleResult();
		return  Optional.ofNullable(t);
	}



}
