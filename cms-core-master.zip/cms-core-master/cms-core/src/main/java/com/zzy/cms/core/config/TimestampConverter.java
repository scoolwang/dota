package com.zzy.cms.core.config;
 
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
 

/**
 * 
 * @author guokaige
 * @Date   2019年3月26日 上午9:46:05
 */
public class TimestampConverter implements Converter<String, Timestamp> {
 
    private static final List<String> FORMATS = new ArrayList<>(4);
    static{
        FORMATS.add("yyyy-MM");
        FORMATS.add("yyyy-MM-dd");
        FORMATS.add("yyyy-MM-dd HH:mm");
        FORMATS.add("yyyy-MM-dd HH:mm:ss");
    }
 
    @Override
    public Timestamp convert(String source) {
        String value = source.trim();
        if ("".equals(value)) {
            return null;
        }
        if(source.matches("^\\d{4}-\\d{1,2}$")){
            return parseTimestamp(source, FORMATS.get(0));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2}$")){
            return parseTimestamp(source, FORMATS.get(1));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2} {1}\\d{1,2}:\\d{1,2}$")){
            return parseTimestamp(source, FORMATS.get(2));
        }else if(source.matches("^\\d{4}-\\d{1,2}-\\d{1,2} {1}\\d{1,2}:\\d{1,2}:\\d{1,2}$")){
            return parseTimestamp(source, FORMATS.get(3));
        }else {
            throw new IllegalArgumentException("Invalid timestamp value '" + source + "'");
        }
    }
 
    /**
     * 格式化日期
     * @param dateStr String 字符型日期
     * @param format String 格式
     * @return Date 日期
     */
    public Timestamp parseTimestamp(String dateStr, String format) {
    	Timestamp timestamp=null;
        try {
            DateFormat dateFormat = new SimpleDateFormat(format);
            timestamp = new Timestamp(dateFormat.parse(dateStr).getTime());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return timestamp;
    }
 
}
