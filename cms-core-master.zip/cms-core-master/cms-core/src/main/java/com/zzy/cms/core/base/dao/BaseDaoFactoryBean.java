package com.zzy.cms.core.base.dao;

import java.io.Serializable;

import javax.persistence.EntityManager;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaRepositoryFactoryBean;
import org.springframework.data.repository.core.support.RepositoryFactorySupport;

/**
 * 
 * @author guokaige
 * @param <R>
 * @param <S>
 * @param <ID>
 */
public class BaseDaoFactoryBean<R extends JpaRepository<S, ID>, S, ID extends Serializable> extends JpaRepositoryFactoryBean<R, S, ID> {

	public BaseDaoFactoryBean(Class<? extends R> repositoryInterface) {
		super(repositoryInterface);
	}

	@Override
	protected RepositoryFactorySupport createRepositoryFactory(EntityManager entityManager) {
		return new BaseDaoFactory<S, ID>(entityManager);
	}

	@Override
	public void afterPropertiesSet() {
		super.afterPropertiesSet();
	}

}
