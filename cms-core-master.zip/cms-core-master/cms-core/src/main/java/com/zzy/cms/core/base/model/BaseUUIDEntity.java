package com.zzy.cms.core.base.model;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.hibernate.annotations.GenericGenerator;

/**
 * 
 * @author guokaige
 *
 */
@MappedSuperclass
public class BaseUUIDEntity extends BaseObject implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator = "cms-uuid")
	@GenericGenerator(name = "cms-uuid", strategy = "com.zzy.cms.core.base.model.id.ManulUuidGenerator")
	@Column(name = "ID", length = 36)
	protected String id;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

	/**
	 * 深克隆
	 * @return
	 * @throws Exception
	 */
	public Object deepClone() throws Exception {
		// 序列化
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		ObjectOutputStream oos = new ObjectOutputStream(bos);
		oos.writeObject(this);
		// 反序列化
		ByteArrayInputStream bis = new ByteArrayInputStream(bos.toByteArray());
		ObjectInputStream ois = new ObjectInputStream(bis);
		return ois.readObject();
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (getClass() != obj.getClass()) {
			return false;
		}
		BaseModelUUIDEntity other = (BaseModelUUIDEntity) obj;
		if(id.equals(other.getId())) {
			return true;
		}
		return false; 
	}

	@Override
	public int hashCode() {
		return id == null ? 0 : id.hashCode();
	}

}
