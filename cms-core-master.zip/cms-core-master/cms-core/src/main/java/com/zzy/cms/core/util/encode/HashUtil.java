package com.zzy.cms.core.util.encode;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * @author zhaoxiubin 创建日期:2018/7/6 哈希功能封装功能类
 * @version V1.0
 */
public class HashUtil {

	/**
	 * 默认的密码字符串组合，用来将字节转换成 16 进制表示的字符
	 */
	private static final char[] HEX_DIGITS = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };

	/**
	 * MD5算法名称
	 */
	public static final String HASH_MD5 = "MD5";
	/**
	 * SHA1算法名称
	 */
	public static final String HASH_SHA1 = "SHA1";
	/**
	 * SHA-256算法名称
	 */
	public static final String HASH_SHA256 = "SHA-256";
	/**
	 * SHA-256算法名称
	 */
	public static final String HASH_SHA512 = "SHA-512";

	/**
	 * 将字符串进行MD5哈希
	 * 
	 * @param str 要MD5哈希的字符串
	 * @return MD5哈希后字符串
	 */
	public static String md5(String str) {
		return hash(str, HASH_MD5);
	}

	/**
	 * 将字符串进行SHA1哈希
	 * 
	 * @param str 要SHA1哈希的字符串
	 * @return SHA1哈希后字符串
	 */
	public static String sha1(String str) {
		return hash(str, HASH_SHA1);
	}

	/**
	 * 将字符串进行SHA-256哈希
	 * 
	 * @param str 要SHA-256哈希的字符串
	 * @return SHA-256哈希后字符串
	 */
	public static String sha256(String str) {
		return hash(str, HASH_SHA256);
	}

	/**
	 * 将字符串进行SHA-512哈希
	 * 
	 * @param str 要SHA-512哈希的字符串
	 * @return SHA-512哈希后字符串
	 */
	public static String sha512(String str) {
		return hash(str, HASH_SHA512);
	}

	/**
	 * 将文件进行MD5哈希
	 * 
	 * @param file 要MD5哈希的文件
	 * @return MD5哈希后字符串
	 */
	public static String md5(File file) {
		return hash(file, HASH_MD5);
	}

	/**
	 * 将文件进行SHA1哈希
	 * 
	 * @param file 要SHA1哈希的文件
	 * @return SHA1哈希后字符串
	 */
	public static String sha1(File file) {
		return hash(file, HASH_SHA1);
	}

	/**
	 * 将文件进行SHA-256哈希
	 * 
	 * @param file 要SHA-256哈希的文件
	 * @return SHA-256哈希后字符串
	 */
	public static String sha256(File file) {
		return hash(file, HASH_SHA256);
	}

	/**
	 * 将文件进行SHA-512哈希
	 * 
	 * @param file 要SHA-512哈希的文件
	 * @return SHA-512哈希后字符串
	 */
	public static String sha512(File file) {
		return hash(file, HASH_SHA512);
	}

	/**
	 * 将字符串按照指定算法进行哈希
	 * 
	 * @param messageDigest 要哈希的字符串
	 * @return 哈希后字符串
	 */
	public static String hash(String messageDigest, String algorithm) {
		if (messageDigest == null) {
			return null;
		}
		try {
			MessageDigest md = MessageDigest.getInstance(algorithm);
			md.update(messageDigest.getBytes("UTF-8"));
			return HashUtil.bytesToHex(md.digest());
		} catch (Exception e) {
			return null;
		}
	}

	/**
	 * 将文件进行哈希
	 * 
	 * @param file 要哈希的文件
	 * @return 哈希后字符串
	 */
	public static String hash(File file, String algorithm) {
		MessageDigest md;
		InputStream fis = null;
		try {
			md = MessageDigest.getInstance(algorithm);
			fis = new FileInputStream(file);
			byte[] buffer = new byte[1024];
			int numRead = 0;
			while ((numRead = fis.read(buffer)) > 0) {
				md.update(buffer, 0, numRead);
			}
		} catch (IOException e) {
			return null;
		} catch (NoSuchAlgorithmException e) {
			return null;
		} finally {
			if (null != fis) {
				try {
					fis.close();
				} catch (IOException e) {
				}
			}
		}
		return HashUtil.bytesToHex(md.digest());
	}

	/**
	 * 将字节数组转化成十六进制字符串
	 * 
	 * @param bytes 字节数组
	 * @return 十六进制的字符串
	 */
	public static String bytesToHex(byte[] bytes) {
		int len = bytes.length;
		StringBuilder buf = new StringBuilder(len * 2);
		// 把密文转换成十六进制的字符串形式
		for (int j = 0; j < len; j++) {
			buf.append(HEX_DIGITS[(bytes[j] >> 4) & 0x0f]);
			buf.append(HEX_DIGITS[bytes[j] & 0x0f]);
		}
		return buf.toString();
	}
	

    public static void main(String[] args) {
        String str = "啦啦啦，我是字符串！";
        System.out.println("MD5前的字符串：" + str);
        File file = new File("E:/aaf.jar");

        String hashStrMd5 = HashUtil.hash(str, "MD5");
        System.out.println("hash算法字符串的MD5值为：" + hashStrMd5);
        String hashStrSha1 = HashUtil.hash(str, "SHA1");
        System.out.println("hash算法字符串的SHA1值为：" + hashStrSha1 + "\n\n");

        String hashFileMd5 = HashUtil.hash(file, "MD5");
        System.out.println("hash算法文件的MD5值为：" + hashFileMd5);
        String hashFileSha1 = HashUtil.hash(file, "SHA1");
        System.out.println("hash算法文件的SHA1值为：" + hashFileSha1);
    }
}
