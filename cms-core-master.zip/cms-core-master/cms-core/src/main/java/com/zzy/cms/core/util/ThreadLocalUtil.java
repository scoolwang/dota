package com.zzy.cms.core.util;

import java.util.Map;

import com.google.common.collect.Maps;

/**
 * 
 * @author guokaige
 * @date: 2018年11月14日 下午2:14:17
 */
public class ThreadLocalUtil {
	
	public static final ThreadLocal<Map<String,Object>> INSTANCE = new ThreadLocal<Map<String,Object>>() {

		@Override
		protected Map<String, Object> initialValue() {
			return Maps.newHashMap();
		}

	};

	
	public static Map<String,Object> getThreadMap() {
		return ThreadLocalUtil.INSTANCE.get();
	}
	
	
    public static void main(String[] args) {
    	ThreadLocalUtil.INSTANCE.get().put("111", "2222");
      	System.out.println(ThreadLocalUtil.INSTANCE.get().get("111"));
      	
      	ThreadLocalUtil.getThreadMap().put("111", "33333");
      	System.out.println( ThreadLocalUtil.getThreadMap().get("111") );
      	
	}


}