package com.zzy.cms.core.util.string;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 特殊字符检测工具
 * @author guokaige
 *
 */
public class IllegalStrFilterUtil {

    private static final String REGX = "!|！|@|◎|#|＃|(\\$)|￥|%|％|(\\^)|……|(\\&)|※|(\\*)|×|(\\()|（|(\\))|）|_|——|(\\+)|＋|(\\|)|§ ";

    
    private static final String SQL_DELETE ="DELETE";
    private static final String SQL_ASCII ="ASCII";
    private static final String SQL_UPDATE ="UPDATE";
    private static final String SQL_SELECT ="SELECT";
    private static final String SQL_QUOTE ="'";
    private static final String SQL_SUBSTR ="SUBSTR(";
    private static final String SQL_COUNT ="COUNT(";
    private static final String SQL_OR =" OR ";
    private static final String SQL_AND ="AND";
    private static final String SQL_DROP ="DROP";
    private static final String SQL_EXECUTE ="EXECUTE";
    private static final String SQL_EXEC ="EXEC";
    private static final String SQL_TRUNCATE ="TRUNCATE";
    private static final String SQL_INTO ="INTO";
    private static final String SQL_DECLARE ="DECLARE";
    private static final String SQL_MASTER ="MASTER";
    
    /**
     * 对常见的sql注入攻击进行拦截
     *
     * @param sInput
     * @return
     *  true 表示参数不存在SQL注入风险
     *  false 表示参数存在SQL注入风险
     */
    public static Boolean sqlStrFilter(String sInput) {
        if (sInput == null || sInput.trim().length() == 0) {
            return false;
        }
        sInput = sInput.toUpperCase();

        if (sInput.indexOf(SQL_DELETE) >= 0 || sInput.indexOf(SQL_ASCII) >= 0 || sInput.indexOf(SQL_UPDATE) >= 0 || sInput.indexOf(SQL_SELECT) >= 0
                || sInput.indexOf(SQL_QUOTE) >= 0 || sInput.indexOf(SQL_SUBSTR) >= 0 || sInput.indexOf(SQL_COUNT) >= 0 || sInput.indexOf(SQL_OR) >= 0
                || sInput.indexOf(SQL_AND) >= 0 || sInput.indexOf(SQL_DROP) >= 0 || sInput.indexOf(SQL_EXECUTE) >= 0 || sInput.indexOf(SQL_EXEC) >= 0
                || sInput.indexOf(SQL_TRUNCATE) >= 0 || sInput.indexOf(SQL_INTO) >= 0 || sInput.indexOf(SQL_DECLARE) >= 0 || sInput.indexOf(SQL_MASTER) >= 0) {
            return false;
        }
        return true;
    }
 
    /**
     * 对非法字符进行检测
     *
     * @param sInput
     * @return
     *  true 表示参数不包含非法字符
     *  false 表示参数包含非法字符
     */
    public static Boolean isIllegalStr(String sInput) {
 
        if (sInput == null || sInput.trim().length() == 0) {
            return false;
        }
        sInput = sInput.trim();
        Pattern compile = Pattern.compile(REGX, Pattern.CASE_INSENSITIVE);
        Matcher matcher = compile.matcher(sInput);
        return matcher.find();
    }
}
