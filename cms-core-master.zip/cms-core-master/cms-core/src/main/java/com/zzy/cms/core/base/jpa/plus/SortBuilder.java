package com.zzy.cms.core.base.jpa.plus;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.domain.Sort.Order;

/**
 * 
 * @author kaige
 *
 * @param <T>
 */
public class SortBuilder {

	private List<Order> list = new ArrayList<Order>();

	public SortBuilder addOrder(String propertyName, Direction desc) {
		Order order = new Order(desc, propertyName);
		list.add(order);
		return this;
	}
	
	public Sort buildSort() {
		Sort sort = Sort.unsorted();
		if (null != list && !list.isEmpty()) {
			sort = Sort.by(list);
		}
		return sort;
	}

}
